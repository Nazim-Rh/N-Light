#!/usr/bin/env bash
# N-Light installer
#
# Run this from the folder that contains both "installer/" and
# ".transient/" (i.e. run it as: bash installer/install.sh)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SRC_DIR="$PACKAGE_ROOT/.transient"
README_SRC="$PACKAGE_ROOT/README.txt"

if [ ! -d "$SRC_DIR" ]; then
    echo "Error: could not find .transient/ next to installer/ (looked in $PACKAGE_ROOT)"
    exit 1
fi

echo "=== N-Light installer ==="
echo

DEFAULT_PATH="$HOME"
read -rp "Where should N-Light be installed? [default: $DEFAULT_PATH]: " INSTALL_PARENT
INSTALL_PARENT="${INSTALL_PARENT:-$DEFAULT_PATH}"
INSTALL_PARENT="${INSTALL_PARENT/#\~/$HOME}"

if [ ! -d "$INSTALL_PARENT" ]; then
    echo "Creating $INSTALL_PARENT"
    mkdir -p "$INSTALL_PARENT"
fi

# --- Layout created under $INSTALL_PARENT -------------------------------
#
#   N-Light/            <- visible folder, this is "the app"
#     N-Light.sh          <- launcher (run this)
#     Readme.md            <- docs
#     .N-Light/            <- hidden, everything else lives in here
#                             (venv, N-Light/ code, ui/, requirements.txt...)
#
APP_DIR="$INSTALL_PARENT/N-Light"
HIDDEN_DIR="$APP_DIR/.N-Light"

if [ -e "$APP_DIR" ]; then
    read -rp "$APP_DIR already exists. Overwrite? [y/N]: " OVERWRITE
    if [[ "$OVERWRITE" =~ ^[Yy]$ ]]; then
        rm -rf "$APP_DIR"
    else
        echo "Aborting install."
        exit 1
    fi
fi

echo "Creating $APP_DIR ..."
mkdir -p "$APP_DIR"

echo "Copying app files to $HIDDEN_DIR ..."
cp -r "$SRC_DIR" "$HIDDEN_DIR"

echo
echo "Checking for python3..."
if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 not found. Please install Python 3.8+ and re-run this script."
    exit 1
fi

echo "Creating virtual environment..."
python3 -m venv "$HIDDEN_DIR/venv"
source "$HIDDEN_DIR/venv/bin/activate"

echo "Installing Python requirements (PyQt5, pexpect, astropy, matplotlib, numpy)..."
pip install --upgrade pip >/dev/null
pip install -r "$HIDDEN_DIR/requirements.txt"

deactivate

chmod +x "$HIDDEN_DIR/N-Light.sh"

echo
echo "Note: N-Light drives your existing laxpcsoft executables"
echo "(laxpcl1.e, backshiftv3.e) and HEASoft's lcurve -- it does not"
echo "install or build those. Make sure they're already built, and"
echo "that HEASoft is initialised (heainit) before launching N-Light"
echo "if you're not launching it from an already-initialised shell."
echo

# --- Visible launcher (outside the hidden folder) -----------------------
# Just forwards to the real launcher in .N-Light/, so the only things
# you ever need to touch in N-Light/ are this file and Readme.md -- the
# .N-Light/ folder holds everything else and is hidden by convention
# (leading dot), same as before.
cat > "$APP_DIR/N-Light.sh" << EOF
#!/usr/bin/env bash
# Thin launcher -- forwards to the real app in .N-Light/
HERE="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
exec "\$HERE/.N-Light/N-Light.sh" "\$@"
EOF
chmod +x "$APP_DIR/N-Light.sh"

# --- Visible README (outside the hidden folder) -------------------------
if [ -f "$README_SRC" ]; then
    cp "$README_SRC" "$APP_DIR/Readme.md"
else
    cp "$HIDDEN_DIR/README.txt" "$APP_DIR/Readme.md"
fi

# --- Desktop launcher --------------------------------------------------
# Icon= only actually shows something once you've dropped a N-Light.png
# into ui/ (either before installing, or into $HIDDEN_DIR/ui/ afterwards).
ICON_PATH="$HIDDEN_DIR/ui/N-Light.png"
DESKTOP_SRC="$HIDDEN_DIR/N-Light.desktop"

cat > "$DESKTOP_SRC" << EOF
[Desktop Entry]
Type=Application
Name=N-Light
Comment=AstroSat LAXPC lightcurve reduction UI
Exec="$APP_DIR/N-Light.sh"
Icon=$ICON_PATH
Terminal=false
Categories=Science;Astronomy;
StartupWMClass=N-Light
EOF
chmod +x "$DESKTOP_SRC"

# Applications menu entry
APPS_DIR="$HOME/.local/share/applications"
mkdir -p "$APPS_DIR"
cp "$DESKTOP_SRC" "$APPS_DIR/N-Light.desktop"
chmod +x "$APPS_DIR/N-Light.desktop"
command -v update-desktop-database >/dev/null 2>&1 && \
    update-desktop-database "$APPS_DIR" >/dev/null 2>&1 || true

# Desktop icon -- also drop a launcher on the user's actual Desktop.
# Respect XDG_DESKTOP_DIR / xdg-user-dir if set up, else fall back to
# ~/Desktop (creating it if it doesn't exist yet).
if command -v xdg-user-dir >/dev/null 2>&1; then
    DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
fi
DESKTOP_DIR="${DESKTOP_DIR:-$HOME/Desktop}"
mkdir -p "$DESKTOP_DIR"
cp "$DESKTOP_SRC" "$DESKTOP_DIR/N-Light.desktop"
chmod +x "$DESKTOP_DIR/N-Light.desktop"
# Some desktop environments (GNOME/Nautilus in particular) refuse to treat
# a .desktop file on the Desktop as a trusted launcher until its metadata
# says so -- otherwise it just shows up as an inert text file icon.
command -v gio >/dev/null 2>&1 && \
    gio set "$DESKTOP_DIR/N-Light.desktop" "metadata::trusted" true >/dev/null 2>&1 || true

echo "=== Install complete ==="
echo "Installed to: $APP_DIR"
echo
echo "  $APP_DIR/"
echo "    N-Light.sh   <- run this to launch N-Light"
echo "    Readme.md    <- docs"
echo "    .N-Light/    <- app internals (hidden -- leading dot, leave alone)"
echo
echo "Launch it with:"
echo "  $APP_DIR/N-Light.sh"
echo
echo "A desktop launcher (N-Light.desktop) was installed to:"
echo "  - $APPS_DIR (application menu)"
echo "  - $DESKTOP_DIR (an icon on your Desktop)"
echo "If you haven't dropped a N-Light.png into ui/ yet, do so and"
echo "re-run the installer (or just replace $ICON_PATH afterwards) to"
echo "give both of those a proper icon instead of the default Qt one."
echo
echo "On first launch, open Run once to see the Settings dialog and set:"
echo "  - LAXPC1 software dir (your eclipse_gti folder)"
echo "  - Output base path"
echo "to match your machine."

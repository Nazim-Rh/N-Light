#!/usr/bin/env bash
# Launches N-Light using the venv created by installer/install.sh.
# This script lives inside the hidden .N-Light/ folder; the visible
# N-Light.sh next to it (one level up) just forwards here.
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- Logo / app icon -------------------------------------------------------
# If ui/N-Light.png is present next to this script, point the app at it so
# it can use it as the window/taskbar icon. Harmless if it's not there yet.
if [ -f "$HERE/ui/N-Light.png" ]; then
    export NLIGHT_ICON_PATH="$HERE/ui/N-Light.png"
fi

# --- Make sure HEASoft (lcurve) is on PATH -------------------------------
# If lcurve is already available (e.g. you ran heainit yourself before
# launching this script), do nothing. Otherwise try to find and source
# headas-init.sh ourselves so you don't have to remember to run heainit
# every time.
if ! command -v lcurve >/dev/null 2>&1; then
    HEADAS_INIT=""

    # 1) Respect an already-set $HEADAS env var if present.
    if [ -n "$HEADAS" ] && [ -f "$HEADAS/headas-init.sh" ]; then
        HEADAS_INIT="$HEADAS/headas-init.sh"
    fi

    # 2) Otherwise, search for it. HEASoft installs vary in nesting
    #    depth (~/heasoft/headas-init.sh vs ~/heasoft/heasoft-X.Y/<arch>/
    #    headas-init.sh, etc.), and a full HEASoft source tree also
    #    contains many decoy headas-init.sh copies under BUILD_DIR/
    #    (per-tool build dirs) -- skip those, we only want the real
    #    top-level one that lives next to bin/, lib/, refdata/.
    if [ -z "$HEADAS_INIT" ]; then
        for base in "$HOME" /opt /usr/local; do
            [ -d "$base" ] || continue
            found="$(find "$base" -maxdepth 6 -iname 'headas-init.sh' \
                        -not -path '*/BUILD_DIR/*' 2>/dev/null | sort | head -n1)"
            if [ -n "$found" ]; then
                HEADAS_INIT="$found"
                break
            fi
        done
    fi

    if [ -n "$HEADAS_INIT" ]; then
        echo "Initializing HEASoft from $HEADAS_INIT ..."
        # headas-init.sh expects $HEADAS to point at the arch-specific dir
        # (the one directly containing bin/, lib/, etc.) -- that's the
        # directory headas-init.sh itself lives in.
        export HEADAS="$(dirname "$HEADAS_INIT")"
        source "$HEADAS_INIT"
    else
        echo "Warning: could not find headas-init.sh automatically."
        echo "If HEASoft isn't already initialized in this shell, the lcurve"
        echo "step will fail. Set \$HEADAS or edit the search paths in"
        echo "N-Light.sh to point at your HEASoft install."
    fi
fi

if [ -d "$HERE/venv" ]; then
    source "$HERE/venv/bin/activate"
fi

cd "$HERE"
python3 -m N-Light.main "$@"

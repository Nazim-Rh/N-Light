"""
Pipeline logic for N-Light.

Wraps the existing laxpcsoft Fortran executables (laxpcl1.e,
backshiftv3.e) and HEASoft's lcurve, following the same sequence as
the LAXPC Format-B walkthrough:

    findfile -> laxpcl1.inp -> laxpcl1.e -> gti.inp -> laxpcl1.e
    -> backshiftv3.e -> laxpcl1.e -> lcurve -> plots

This module does NOT reimplement any of the LAXPC reduction math --
it only automates typing the same answers you'd type by hand, and
turns the resulting FITS lightcurve into plots (including one plot
per GTI, saved in a `gti_plots/` subfolder).
"""

import os
import re
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import pexpect


LogFn = Callable[[str], None]


# ---------------------------------------------------------------------------
# File discovery (the "findfile" step, done in Python instead of grep/find)
# ---------------------------------------------------------------------------

def discover_orbit_files(orbit_dir: str, laxpc_unit: int, log: LogFn) -> List[str]:
    """
    For one orbit folder, return the 4 files findfile normally collects:
      <orbit>/*.mkf
      <orbit>/aux/*.tct
      <orbit>/lxp<unit>/modeBB/*BB_level1.fits
      <orbit>/lxp<unit>/modeEA/*EA_level1.fits
    """
    found = []

    def _one(glob_dir, suffix):
        if not os.path.isdir(glob_dir):
            return None
        for fn in sorted(os.listdir(glob_dir)):
            if fn.endswith(suffix):
                return os.path.join(glob_dir, fn)
        return None

    mkf = _one(orbit_dir, ".mkf")
    tct = _one(os.path.join(orbit_dir, "aux"), ".tct")
    bb = _one(os.path.join(orbit_dir, f"lxp{laxpc_unit}", "modeBB"), "BB_level1.fits")
    ea = _one(os.path.join(orbit_dir, f"lxp{laxpc_unit}", "modeEA"), "EA_level1.fits")

    for label, path in (("mkf", mkf), ("tct", tct), ("BB fits", bb), ("EA fits", ea)):
        if path is None:
            log(f"  ! could not find {label} under {orbit_dir}")
        else:
            found.append(path)

    return found


def build_laxpcl1_inp(orbit_dirs: List[str], laxpc_unit: int, workdir: str, log: LogFn) -> str:
    """Write laxpcl1.inp in workdir, listing files from all orbit dirs."""
    lines = []
    for orbit_dir in orbit_dirs:
        files = discover_orbit_files(orbit_dir, laxpc_unit, log)
        lines.extend(files)

    inp_path = os.path.join(workdir, "laxpcl1.inp")
    with open(inp_path, "w") as f:
        f.write("\n".join(lines) + "\n")

    log(f"Wrote {inp_path} ({len(lines)} files from {len(orbit_dirs)} orbit(s))")
    return inp_path


# ---------------------------------------------------------------------------
# Interactive executable drivers (pexpect)
# ---------------------------------------------------------------------------

# Width of the pseudo-terminal we give every spawned tool.
#
# This is NOT cosmetic. HEASoft's parameter prompts go through GNU
# readline, which keeps the whole prompt + default value on one physical
# line: if it doesn't fit the terminal width, readline scrolls the line
# horizontally and replaces the hidden start with a single '<'. pexpect's
# default pty is 80 columns, so a prompt like
#
#     Ser. 1 filename +options (or @file of filenames +options)[EXO 0748-676_combined.lc]
#
# (~84 chars) arrived as "<e of filenames +options)[...]" -- the literal
# text "Ser. 1 filename" was never sent at all, so expect() could never
# match it and the step sat there until step_timeout fired. A wide pty
# means readline never needs to scroll and prompts arrive intact.
PTY_DIMENSIONS = (50, 500)


def _heasoft_env(workdir: str) -> dict:
    """
    Environment for a spawned HEASoft tool, with a private PFILES
    directory under workdir.

    HEASoft remembers the last value you gave every prompt in a .par
    file (normally ~/pfiles). A killed or half-finished run therefore
    leaves stale defaults behind that the next run inherits -- which is
    where the surprise 'EXO 0748-676_combined.lc' default above came
    from. Pointing PFILES at a per-workdir directory keeps each run's
    parameter state to itself.

    Falls back to the unmodified environment if HEADAS isn't set or the
    directory can't be created -- never worth failing a run over.
    """
    env = os.environ.copy()
    headas = env.get("HEADAS")
    if not headas:
        return env
    try:
        local_pfiles = os.path.join(workdir, ".nlight_pfiles")
        os.makedirs(local_pfiles, exist_ok=True)
        env["PFILES"] = f"{local_pfiles};{os.path.join(headas, 'syspfiles')}"
    except OSError:
        pass
    return env


def _spawn(cmd: str, cwd: str, log: LogFn, timeout: int) -> pexpect.spawn:
    log(f"$ {cmd}   (cwd={cwd})")
    child = pexpect.spawn(
        cmd,
        cwd=cwd,
        timeout=timeout,
        encoding="utf-8",
        dimensions=PTY_DIMENSIONS,
        env=_heasoft_env(cwd),
    )
    child.logfile_read = _LogWriter(log)
    _register_current_child(child)
    return child


# ---------------------------------------------------------------------------
# Stop/kill support -- lets a Stop button abort whatever laxpcl1.e /
# backshiftv3.e / lcurve process is running right now, instead of
# waiting for it to finish on its own. Only one of these subprocesses
# is ever running at a time (each pipeline step spawns, drives, and
# closes its own before the next one starts), so tracking a single
# "current" child is enough.
# ---------------------------------------------------------------------------

_current_child_lock = threading.Lock()
_current_child: Optional[pexpect.spawn] = None


def _register_current_child(child: pexpect.spawn) -> None:
    global _current_child
    with _current_child_lock:
        _current_child = child


def kill_current_process(log: Optional[LogFn] = None) -> bool:
    """
    Forcibly kill whichever laxpcl1.e / backshiftv3.e / lcurve process
    is currently running, if any. pexpect gives each spawned process
    its own session (it's the leader of its own process group), so we
    kill the whole group -- not just the one pid -- in case the
    Fortran/HEASoft binary has spawned anything of its own. Returns
    True if a live process was actually found and killed.
    """
    with _current_child_lock:
        child = _current_child
    if child is None or not getattr(child, "pid", None):
        return False
    try:
        if not child.isalive():
            return False
        try:
            os.killpg(os.getpgid(child.pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            child.kill(signal.SIGKILL)
        child.close(force=True)
    except Exception:
        pass
    if log:
        log("  ! Process killed (Stop pressed).")
    return True


class _LogWriter:
    """
    Adapter so pexpect can stream raw output into our log callback.

    Only splitting on "\\n" hides exactly the output you most need when
    something goes wrong: HEASoft prompts leave the cursor on the same
    line (no trailing newline), so a stalled step used to show nothing
    at all in the log past the last *Fortran* prompt. Anything that
    looks like a finished prompt -- i.e. ends in "[default]" -- is
    flushed out immediately as well.
    """
    def __init__(self, log: LogFn):
        self.log = log
        self._buf = ""

    def write(self, data):
        self._buf += data
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            line = line.rstrip("\r")
            if line.strip():
                self.log(line)
        pending = self._buf.rstrip()
        if pending.endswith("]"):
            self.log(pending.rstrip("\r"))
            self._buf = ""

    def flush(self):
        if self._buf.strip():
            self.log(self._buf.rstrip("\r"))
        self._buf = ""


def run_laxpcl1(params: dict, workdir: str, log: LogFn) -> None:
    """Drive one interactive run of ./laxpcl1.e"""
    exe = os.path.join(workdir, "laxpcl1.e")
    if not os.path.isfile(exe):
        raise FileNotFoundError(
            f"laxpcl1.e not found in {workdir} -- check the LAXPC1 path in Settings, "
            "and that laxpcsoft has been built there (make laxpcl1)."
        )

    child = _spawn(exe, workdir, log, params["step_timeout"])
    child.expect("Type lxp,tbin,anode")
    child.sendline(f"{params['lxp']} {params['tbin']} {params['anode']}")

    child.expect("Type channel range for light curve")
    child.sendline(f"{params['chan_min']} {params['chan_max']}")

    child.expect("Type No. of channels in spectrum")
    child.sendline(str(params["nchan_spectrum"]))

    child.expect("Type uld bin")
    child.sendline(f"{params['uld_bin']} {params['earth_occ']} {params['event_flag']}")

    child.expect(pexpect.EOF)
    child.close()
    log("laxpcl1.e finished.\n")


def promote_gti(workdir: str, log: LogFn) -> str:
    """mv lxp2level2.gti -> gti.inp (matches the observed run's filename)."""
    src = os.path.join(workdir, "lxp2level2.gti")
    if not os.path.isfile(src):
        # fall back: pick up any *.gti freshly written
        candidates = [f for f in os.listdir(workdir) if f.endswith(".gti")]
        if not candidates:
            raise FileNotFoundError("No .gti file produced by laxpcl1.e run 1.")
        src = os.path.join(workdir, sorted(candidates)[0])

    dst = os.path.join(workdir, "gti.inp")
    shutil.copyfile(src, dst)
    log(f"Copied {src} -> {dst}")
    return dst


def run_backshiftv3(params: dict, workdir: str, log: LogFn) -> dict:
    """
    Drive one interactive run of ./backshiftv3.e.
    Returns a dict with whatever the program reported (response file,
    gain offset, suggested alternate background) so the caller can
    show it to the user before deciding whether to edit back4.inp and
    re-run.
    """
    exe = os.path.join(workdir, "backshiftv3.e")
    if not os.path.isfile(exe):
        raise FileNotFoundError(
            f"backshiftv3.e not found in {workdir} -- check the LAXPC1 path in Settings."
        )

    child = _spawn(exe, workdir, log, params["step_timeout"])
    child.expect("type lxp,anode,idi")
    child.sendline(f"{params['lxp']} {params['anode']} {params['backshift_idi']}")

    child.expect("Type time-bin, channel range for light curve, nul")
    child.sendline(
        f"{params['backshift_timebin']} {params['chan_min']} "
        f"{params['chan_max']} {params['backshift_nul']}"
    )

    child.expect(r"type \.pha file name")
    pha = params.get("pha_filename") or ""
    child.sendline(pha if pha else "/")

    child.expect(pexpect.EOF)
    output = child.before or ""
    child.close()
    log("backshiftv3.e finished.\n")

    result = {"raw": output}
    m = re.search(r"use the response file\s+(\S+)", output)
    if m:
        result["response_file"] = m.group(1)
    m = re.search(r"Use gain-offset\s*=\s*([-\d.]+)\s*keV", output)
    if m:
        result["gain_offset_kev"] = float(m.group(1))
    m = re.search(r"It may be better to use\s+(\S+)", output)
    if m:
        result["suggested_background"] = m.group(1)

    return result


def edit_back4_inp_first_line(workdir: str, new_backfit_line: str, log: LogFn) -> None:
    """Replace the first line of back4.inp (the backfit.<epoch> line)."""
    path = os.path.join(workdir, "back4.inp")
    with open(path) as f:
        lines = f.readlines()
    if not lines:
        raise ValueError("back4.inp is empty")
    lines[0] = new_backfit_line.strip() + "\n"
    with open(path, "w") as f:
        f.writelines(lines)
    log(f"back4.inp updated: line 1 -> {new_backfit_line.strip()}")


_MIN_NEWBIN_RE = re.compile(r"Minimum Newbin Time\s+([0-9.eE+\-]+)\s*\(s\)")
_NUM_ROWS_RE = re.compile(r"No\.\s*of\s*Rows\s*\.*\s*(\d+)")
_MAX_NEWBIN_RE = re.compile(r"Maximum Newbin No\.*\s*(\d+)")


class BinTooLargeError(RuntimeError):
    """
    Raised when a requested target_bin_seconds can't fit even once into
    the input series' total duration (lcurve's own "Newbin duration is
    longer than total duration" failure) -- caught before we ever send
    an invalid value to lcurve, so callers can stop/skip cleanly instead
    of the pipeline crashing on a raw pexpect EOF.
    """
    def __init__(self, target_bin_seconds: float, total_duration: float, native_bin: float):
        self.target_bin_seconds = target_bin_seconds
        self.total_duration = total_duration
        self.native_bin = native_bin
        super().__init__(
            f"Requested bin size {target_bin_seconds:g}s doesn't fit even "
            f"once into this series' total duration of {total_duration:g}s "
            f"(native/current bin {native_bin:g}s)."
        )


def _parse_min_newbin_time(text: str) -> Optional[float]:
    """
    Pull the input series' native/current bin time (seconds) out of the
    descriptive block lcurve prints just before the "Newbin Time or
    negative rebinning" prompt, e.g.:

        Minimum Newbin Time 0.20000000E-01 (s)

    Returns None if the line isn't found (older/newer HEASoft wording,
    unexpected output, etc.) so the caller can fall back gracefully.
    """
    m = _MIN_NEWBIN_RE.search(text or "")
    if not m:
        return None
    try:
        return float(m.group(1))
    except ValueError:
        return None


def _parse_num_rows(text: str) -> Optional[int]:
    """
    Pull the input's total number of native bins out of lcurve's
    output. "No. of Rows ....... NNN" is printed right after the file
    is selected (before the "Name of the window file" prompt); "for
    Maximum Newbin No.. NNN" is printed right before the "Newbin Time
    or negative rebinning" prompt itself -- which is the block we
    actually capture, and where it matters, so try that first.
    """
    m = _MAX_NEWBIN_RE.search(text or "")
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            pass
    m = _NUM_ROWS_RE.search(text or "")
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


def _expect_prompt_or_die(child, pattern: str, step_desc: str) -> str:
    """
    Like child.expect(pattern), but if lcurve exits (EOF) instead of
    reaching that prompt -- e.g. because it rejected the value we just
    sent -- raise a clear RuntimeError with lcurve's own error text,
    instead of letting a raw pexpect.EOF exception surface.

    Returns child.before (everything lcurve printed since the previous
    prompt), so callers that need to parse it -- e.g. for "Maximum
    Newbin No." right before the Newbins/Interval prompt -- can do so
    without a second round of expect() bookkeeping.
    """
    idx = child.expect([pattern, pexpect.EOF, pexpect.TIMEOUT])
    if idx == 1:
        raise RuntimeError(
            f"lcurve exited unexpectedly while waiting for '{step_desc}'. "
            "Its last output was:\n" + (child.before or "").strip()[-1500:]
        )
    if idx == 2:
        # A plain pexpect.TIMEOUT tells you nothing about what lcurve
        # actually printed, which is what made the readline-scrolled
        # prompt so hard to spot. Show the unconsumed text instead.
        seen = ((child.before or "") + (child.buffer or ""))[-1500:]
        raise RuntimeError(
            f"Timed out waiting for '{step_desc}' (pattern: {pattern!r}). "
            "What lcurve had actually printed, unmatched:\n" + repr(seen)
        )
    return child.before or ""


def run_lcurve(params: dict, workdir: str, out_lc_name: str, log: LogFn,
                target_bin_seconds: Optional[float] = None,
                series_file: Optional[str] = None) -> str:
    """
    Drive HEASoft's `lcurve` non-interactively (we decline the built-in
    PGPLOT plot and make our own from the output file instead).

    target_bin_seconds is the OUTPUT bin size you actually want, in
    real seconds (e.g. 1.0 for the base lightcurve, 10.0 for the
    default plot resolution). lcurve's own prompt doesn't take an
    absolute bin time directly for rebinning -- a *negative* value
    there means "group N of the input's own bins together" -- so we
    read the input file's reported native/current bin time from
    lcurve's own printed output first, then convert:

        grouping = round(target_bin_seconds / native_bin_seconds)

    This is what was going wrong before: the grouping count was being
    sent straight from settings as a raw bin *count*, silently
    assuming a particular native resolution. "Bin size 1" was actually
    sent as "-1" ("group 1 raw bin" = no grouping at all), so the
    output came out at the input's raw ~0.02s resolution instead of a
    real 1-second bin.

    Before sending anything, we also check the input's total duration
    (native bin x row count, both read from the same lcurve output) --
    if target_bin_seconds doesn't fit even once, we raise
    BinTooLargeError ourselves rather than sending an invalid value and
    letting lcurve error out and exit mid-conversation (which used to
    surface as an opaque pexpect EOF crash).

    series_file overrides params['lcurve_series_file'] for this call --
    used to rebin an already-built .lc file by feeding it back into
    lcurve as the input series, the same way you'd reopen exo_combined.lc
    by hand and ask lcurve to group it further.
    """
    exe = shutil.which("lcurve")
    if exe is None:
        raise FileNotFoundError(
            "`lcurve` not found on PATH. Make sure HEASoft is initialised "
            "(e.g. `heainit`) before running N-Light, or add it to PATH."
        )

    child = _spawn("lcurve", workdir, log, params["step_timeout"])

    # Every pattern below matches the TAIL of the prompt (the trailing
    # "[default]") rather than its opening words. The opening words are
    # the part readline drops when a prompt is long, and they're also
    # the part most likely to be reworded between HEASoft releases; the
    # bracketed default is always the last thing printed before the
    # cursor stops. Defaults are matched as [^\]\r\n]* so an arbitrary
    # remembered filename can't break them either.
    _expect_prompt_or_die(
        child, r"Number of time series for this task\[[^\]\r\n]*\]",
        "Number of time series"
    )
    child.sendline("")

    _expect_prompt_or_die(
        child, r"filenames? \+options\)\[[^\]\r\n]*\]",
        "Ser. 1 filename"
    )
    child.sendline(series_file or params.get("lcurve_series_file") or "")

    _expect_prompt_or_die(
        child, r"window file[^\[\r\n]*\[[^\]\r\n]*\]",
        "Name of the window file"
    )
    child.sendline("")

    # lcurve prints a descriptive block here (source name, start/stop
    # time, "No. of Rows", "Minimum Newbin Time ... (s)", etc.) before
    # the rebinning prompt -- capture it so we know the INPUT file's
    # real bin time and total duration.
    info_block = _expect_prompt_or_die(
        child, r"negative rebinning\[[^\]\r\n]*\]",
        "Newbin Time or negative rebinning"
    )
    native_bin = _parse_min_newbin_time(info_block)
    n_rows = _parse_num_rows(info_block)
    total_duration = native_bin * n_rows if (native_bin and n_rows) else None

    if target_bin_seconds is None:
        # Legacy/advanced path: caller wants a literal raw-bin-count
        # grouping, as before.
        grouping_size = int(params.get("lc_grouping_size") or 1000)
    elif native_bin is None or native_bin <= 0:
        log("  ! Could not read the input file's native bin time from "
            "lcurve's output -- falling back to lc_grouping_size as a "
            "raw bin count instead of a real second value.")
        grouping_size = int(params.get("lc_grouping_size") or 1000)
    else:
        if total_duration is not None and target_bin_seconds > total_duration + 1e-9:
            # Send something harmless to let lcurve exit cleanly, then
            # bail out with a clear error instead of an invalid rebin.
            child.terminate(force=True)
            raise BinTooLargeError(target_bin_seconds, total_duration, native_bin)

        grouping_size = max(1, round(target_bin_seconds / native_bin))

        if n_rows is not None and grouping_size >= n_rows:
            # Grouping this many raw bins together would consume the
            # WHOLE series (or more) as a single newbin, leaving no
            # room for even one more newbin after it. Durations alone
            # don't catch this: target_bin_seconds can come out equal
            # to (not just less than) native_bin * n_rows, which looks
            # like it should "just fit" -- but xronos's lcurve engine
            # rejects a newbin that spans the entire duration with
            # "Newbin duration is longer than total duration" and
            # exits, which would otherwise surface as an unhandled
            # RuntimeError instead of the clean BinTooLargeError the
            # sweep already knows how to stop on. So bail out here
            # the same way we do for an outright too-large duration.
            child.terminate(force=True)
            raise BinTooLargeError(target_bin_seconds, total_duration, native_bin)

        achieved = grouping_size * native_bin
        log(f"  Input native/current bin = {native_bin:g}s over "
            f"{total_duration:g}s total -> grouping {grouping_size} raw "
            f"bin(s) for a target of {target_bin_seconds:g}s (actual "
            f"output bin = {achieved:g}s)" if total_duration is not None else
            f"  Input native/current bin = {native_bin:g}s -> grouping "
            f"{grouping_size} raw bin(s) for a target of "
            f"{target_bin_seconds:g}s (actual output bin = {achieved:g}s)")
        if abs(achieved - target_bin_seconds) > 0.01 * target_bin_seconds:
            log(f"  ! {target_bin_seconds:g}s isn't an exact multiple of "
                f"the input's {native_bin:g}s bin -- closest achievable "
                f"is {achieved:g}s.")

    child.sendline(str(-abs(grouping_size)))

    # lcurve prints "Maximum Newbin No. NNNN" (the total count of
    # post-rebin newbins available across the WHOLE series) right
    # before this next prompt.
    rebin_block = _expect_prompt_or_die(
        child, r"Number of Newbins/Interval\[[^\]\r\n]*\]",
        "Number of Newbins/Interval"
    )

    newbins_per_interval = params.get("lcurve_newbins_per_interval")
    if not newbins_per_interval:
        m = _MAX_NEWBIN_RE.search(rebin_block)
        total_newbins = int(m.group(1)) if m else None
        if total_newbins:
            # Force everything into a SINGLE Interval. Left blank,
            # lcurve accepts its own default here (428 in this build)
            # -- and whenever the series needs more than one Interval
            # to fit at that size, only the FIRST Interval's newbins
            # end up in the saved .lc file; every later Interval is
            # only ever shown in the per-Interval stats printed to the
            # terminal, never written to disk. That's what was making
            # every lightcurve here look truncated to ~7 minutes
            # (428s) regardless of the real orbit/combined duration.
            # Requesting the full total instead avoids that silent
            # truncation.
            newbins_per_interval = str(total_newbins)
            log(f"  Requesting all {total_newbins} newbins in a single "
                "Interval (lcurve's own default here would otherwise "
                "keep only the first Interval's data).")

    child.sendline(str(newbins_per_interval or ""))

    _expect_prompt_or_die(
        child, r"Name of output file\[[^\]\r\n]*\]", "Name of output file"
    )
    child.sendline(out_lc_name)

    # From here on, lcurve is doing the real work: reading the whole
    # event file and binning it, printing one "Intv NNNN ..." progress
    # block per interval as it goes. For a big combined multi-orbit run
    # at fine time resolution this is thousands of intervals and can
    # legitimately take a long time -- that's normal, not a hang.
    #
    # So rather than one fixed timeout on "did *anything* match yet",
    # we poll in short slices and only treat it as stuck once no new
    # output at all has appeared for a while (real inactivity), with a
    # generous overall ceiling as a last-resort safety net. This also
    # still tolerates the exact wording of the final "plot?" prompt (or
    # an extra confirmation prompt some HEASoft builds insert) varying
    # slightly between versions.
    plot_prompt = re.compile(r"want.{0,10}to.{0,10}plot", re.IGNORECASE)
    bracket_prompt = re.compile(r"\[[^\]\r\n]*\]\s*$")

    poll_timeout = int(params.get("lcurve_poll_seconds", 30))       # seconds per poll while waiting
    max_idle_polls = int(params.get("lcurve_max_idle_polls", 20))   # e.g. 20*30s = 10 min of true silence -> stuck
    max_total_seconds = params.get("lcurve_max_seconds", 4 * 3600)  # 4h ceiling
    heartbeat_every = 4                # log a heartbeat every ~2 min of busy waiting (at default poll_timeout)

    start = time.monotonic()
    last_len = 0
    idle_polls = 0
    poll_count = 0
    while True:
        idx = child.expect([pexpect.EOF, bracket_prompt, pexpect.TIMEOUT], timeout=poll_timeout)
        if idx == 0:  # program exited
            break
        if idx == 1:  # a bracketed prompt appeared
            idle_polls = 0
            chunk = (child.before or "") + (child.after or "")
            if plot_prompt.search(chunk):
                child.sendline("no")
            else:
                child.sendline("")  # unknown prompt -- accept its default
            continue

        # idx == 2: no match in this poll_timeout window.
        cur_len = len(child.before or "")
        elapsed = time.monotonic() - start
        if cur_len > last_len:
            # Still producing output -- it's just working through a lot
            # of data, not stuck. Reset the idle counter.
            last_len = cur_len
            idle_polls = 0
            poll_count += 1
            if poll_count % heartbeat_every == 0:
                log(f"... lcurve still processing ({int(elapsed)}s elapsed) ...")
        else:
            idle_polls += 1

        if idle_polls >= max_idle_polls:
            raise TimeoutError(
                f"lcurve produced no output at all for {idle_polls * poll_timeout}s "
                "after 'Name of output file' -- it's likely stuck waiting on a "
                "prompt N-Light doesn't recognize. Last output:\n"
                + (child.before or "")[-2000:]
            )
        if elapsed >= max_total_seconds:
            raise TimeoutError(
                f"lcurve has been running for over {int(max_total_seconds / 60)} "
                "minutes without finishing. This may just be a very large/fine-"
                "resolution run -- consider a larger grouping size (fewer, wider "
                "bins) if this keeps happening. Last output:\n"
                + (child.before or "")[-2000:]
            )

    child.close()
    log("lcurve finished.\n")

    out_path = os.path.join(workdir, out_lc_name)
    if not os.path.isfile(out_path):
        # lcurve sometimes appends .lc
        alt = out_path + ".lc"
        if os.path.isfile(alt):
            return alt
        raise FileNotFoundError(f"lcurve did not produce {out_path}")
    return out_path


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

def _find_column(names: List[str], preferred: str) -> Optional[str]:
    """
    lcurve's output column naming varies -- with a single series it's
    often "RATE1"/"ERROR1" rather than plain "RATE"/"ERROR". Accept an
    exact match first, then fall back to any column starting with the
    preferred name (e.g. "RATE1", "RATE2", ...), picking the first one.
    """
    if preferred in names:
        return preferred
    candidates = sorted(n for n in names if n.startswith(preferred))
    return candidates[0] if candidates else None


def plot_lightcurve(lc_fits_path: str, out_png: str, title: str, log: LogFn) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    time, rate, err = _read_rate(lc_fits_path)

    fig, ax = plt.subplots(figsize=(10, 4))
    if err is not None:
        ax.errorbar(time, rate, yerr=err, fmt=".", ms=2, elinewidth=0.5, color="C0")
    else:
        ax.plot(time, rate, ".", ms=2, color="C0")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Rate (counts/s)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    log(f"Saved {out_png}")


def _read_rate(lc_fits_path: str):
    from astropy.io import fits
    with fits.open(lc_fits_path) as hdul:
        rate_hdu = hdul["RATE"] if "RATE" in hdul else hdul[1]
        data = rate_hdu.data
        time = data["TIME"]
        rate_col = _find_column(data.names, "RATE")
        if rate_col is None:
            raise KeyError(f"No RATE-like column found in {lc_fits_path}. Columns: {data.names}")
        rate = data[rate_col]
        err_col = _find_column(data.names, "ERROR")
        err = data[err_col] if err_col else None
    return time, rate, err


def plot_gti_segments(lc_fits_path: str, gti_inp_path: str, out_dir: str, log: LogFn) -> None:
    """
    Read the GTI list (same 4-column format seen in lxp2level2.gti:
    start1 stop1 start2 stop2, two time systems side by side) and save
    one lightcurve plot per good-time-interval.
    """
    from astropy.io import fits
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(out_dir, exist_ok=True)

    with fits.open(lc_fits_path) as hdul:
        rate_hdu = hdul["RATE"] if "RATE" in hdul else hdul[1]
        data = rate_hdu.data
        time = data["TIME"]
        rate_col = _find_column(data.names, "RATE")
        if rate_col is None:
            raise KeyError(f"No RATE-like column found in {lc_fits_path}. Columns: {data.names}")
        rate = data[rate_col]

    gtis = []
    with open(gti_inp_path) as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    # first line is the count; remaining lines are "start stop start2 stop2"
    for ln in lines[1:]:
        parts = ln.split()
        if len(parts) >= 2:
            try:
                start, stop = float(parts[0]), float(parts[1])
                gtis.append((start, stop))
            except ValueError:
                continue

    if not gtis:
        log("No GTIs parsed from gti.inp -- skipping per-GTI plots.")
        return

    t0 = time.min()
    for i, (start, stop) in enumerate(gtis, start=1):
        # GTI times are in mission seconds; light curve TIME column
        # usually is too (or relative -- handle both by windowing on
        # whichever range overlaps the data).
        mask = (time >= start) & (time <= stop)
        if not mask.any():
            # try relative-to-t0 interpretation
            mask = (time >= (start - t0)) & (time <= (stop - t0))
        if not mask.any():
            log(f"  GTI {i}: no matching samples, skipped")
            continue

        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(time[mask], rate[mask], ".", ms=2, color="C1")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Rate (counts/s)")
        ax.set_title(f"GTI {i}  [{start:.1f} - {stop:.1f}]")
        fig.tight_layout()
        out_png = os.path.join(out_dir, f"gti_{i:03d}.png")
        fig.savefig(out_png, dpi=150)
        plt.close(fig)

    log(f"Saved {len(gtis)} GTI plot(s) to {out_dir}")

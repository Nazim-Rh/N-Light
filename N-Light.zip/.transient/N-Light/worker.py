import os
import re
import shutil
import traceback

from PyQt5.QtCore import QThread, pyqtSignal

from . import pipeline


def _safe_file_name(name: str) -> str:
    """
    Collapse anything but [A-Za-z0-9_.-] in a source name to '_'.

    Used for every filename N-Light hands to a HEASoft tool. Spaces are
    the problem: a source called "EXO 0748-676" produced the output
    file "EXO 0748-676_combined.lc", which lcurve then remembered as
    the default for its next input-file prompt -- and HEASoft's own
    parameter syntax treats whitespace as a separator in several
    places, so such a name is a latent failure even once the prompt
    matching is fixed. The display name (plot titles, folder name) is
    left untouched.
    """
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", (name or "").strip()).strip("_")
    return name or "source"


def _safe_folder_name(path: str) -> str:
    """Turn an orbit folder path into a filesystem-safe subfolder name
    (its basename, with anything but [A-Za-z0-9_.-] collapsed to '_')."""
    name = os.path.basename(os.path.normpath(path)) or "orbit"
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_")
    return name or "orbit"


class _StoppedByUser(Exception):
    """Raised internally (via _check_stop()) once request_stop() has
    been called, so _run_pipeline()/_run_one() unwind cleanly at the
    next checkpoint instead of silently ploughing on into the next
    orbit."""
    pass


class PipelineWorker(QThread):
    log_line = pyqtSignal(str)
    stage = pyqtSignal(str)
    finished_ok = pyqtSignal(str)      # emits the source output folder path
    failed = pyqtSignal(str)
    stopped = pyqtSignal()             # emitted when a Stop request was honored
    # emitted once per pipeline run (combined, and each orbit) when
    # backshiftv3 reports a suggestion; result includes a "tag" key
    # identifying which run it came from.
    backshift_result = pyqtSignal(dict)
    # emitted once, after the "combined" run's lightcurve is ready, so
    # the UI can hand it straight to Inspecter: (lc_path, out_dir)
    combined_ready = pyqtSignal(str, str)

    def __init__(self, orbit_dirs, source_name, params, parent=None):
        super().__init__(parent)
        self.orbit_dirs = orbit_dirs
        self.source_name = source_name
        # Display name stays as typed; file_name is what goes into any
        # filename passed to laxpcsoft/lcurve.
        self.file_name = _safe_file_name(source_name)
        self.params = dict(params)
        self._stop_requested = False

    def _log(self, msg: str):
        self.log_line.emit(msg)

    def request_stop(self):
        """Called from the GUI thread (Stop button). Kills whatever
        laxpcl1.e/backshiftv3.e/lcurve process is running right now --
        so we're not just sitting waiting on it -- and marks the run
        to stop at the next checkpoint (_check_stop()) rather than
        starting another step or orbit."""
        self._stop_requested = True
        pipeline.kill_current_process(self._log)

    def _check_stop(self):
        if self._stop_requested:
            raise _StoppedByUser()

    def run(self):
        try:
            self._run_pipeline()
        except _StoppedByUser:
            self._log("\nRun stopped by user.")
            self.stopped.emit()
        except Exception as e:
            if self._stop_requested:
                # Killing the active process makes whatever pipeline
                # call was mid-flight raise some other exception
                # (a pexpect EOF/timeout, or our own "exited
                # unexpectedly" RuntimeError) rather than the clean
                # _StoppedByUser above -- still just a stop, not a
                # real failure.
                self._log("\nRun stopped by user.")
                self.stopped.emit()
                return
            self._log("ERROR: " + str(e))
            self._log(traceback.format_exc())
            self.failed.emit(str(e))

    def _run_pipeline(self):
        p = self.params
        laxpc1_path = os.path.abspath(os.path.expanduser(p["laxpc1_path"]))
        out_base = os.path.abspath(os.path.expanduser(p["output_base_path"]))
        source_dir = os.path.join(out_base, self.source_name)
        os.makedirs(source_dir, exist_ok=True)

        if not os.path.isdir(laxpc1_path):
            raise FileNotFoundError(
                f"LAXPC1 software path does not exist: {laxpc1_path}\n"
                "Set the correct path in Settings."
            )

        # 1) Combined run: all selected orbits reduced together, same as
        #    before, now saved under <source>/combined/.
        combined_dir = os.path.join(source_dir, "combined")
        self._log(f"\n=== Combined ({len(self.orbit_dirs)} orbit(s)) ===")
        self._run_one(
            orbit_dirs=self.orbit_dirs,
            out_dir=combined_dir,
            laxpc1_path=laxpc1_path,
            p=p,
            label_suffix="combined",
            tag="combined",
        )

        # 2) Orbit-wise runs: only meaningful (and only produced) when
        #    more than one orbit was selected. Each orbit gets its own
        #    <source>/<orbit folder name>/ output.
        if len(self.orbit_dirs) > 1:
            used_names = set()
            for orbit_dir in self.orbit_dirs:
                self._check_stop()

                base_name = _safe_folder_name(orbit_dir)
                folder_name = base_name
                n = 2
                while folder_name in used_names:
                    folder_name = f"{base_name}_{n}"
                    n += 1
                used_names.add(folder_name)

                orbit_out_dir = os.path.join(source_dir, folder_name)
                self._log(f"\n=== Orbit: {folder_name} ===")
                self._run_one(
                    orbit_dirs=[orbit_dir],
                    out_dir=orbit_out_dir,
                    laxpc1_path=laxpc1_path,
                    p=p,
                    label_suffix=folder_name,
                    tag=folder_name,
                )

        self.stage.emit("Done")
        self.finished_ok.emit(source_dir)

    def _run_one(self, orbit_dirs, out_dir, laxpc1_path, p, label_suffix, tag):
        """Run the full findfile -> laxpcl1 -> backshift -> lcurve ->
        plots sequence for one set of orbit dirs (either all orbits
        combined, or a single orbit), saving its outputs into out_dir."""
        os.makedirs(out_dir, exist_ok=True)

        self.stage.emit(f"[{tag}] Finding orbit files")
        pipeline.build_laxpcl1_inp(orbit_dirs, p["laxpc_unit"], laxpc1_path, self._log)

        self._check_stop()
        self.stage.emit(f"[{tag}] Running laxpcl1.e (pass 1)")
        pipeline.run_laxpcl1(p, laxpc1_path, self._log)

        self._check_stop()
        self.stage.emit(f"[{tag}] Promoting GTI file")
        gti_inp = pipeline.promote_gti(laxpc1_path, self._log)

        self._check_stop()
        self.stage.emit(f"[{tag}] Running laxpcl1.e (pass 2, with GTI)")
        pipeline.run_laxpcl1(p, laxpc1_path, self._log)

        self._check_stop()
        self.stage.emit(f"[{tag}] Running backshiftv3.e")
        result = pipeline.run_backshiftv3(p, laxpc1_path, self._log)
        result["tag"] = tag
        self.backshift_result.emit(result)

        self._check_stop()
        self.stage.emit(f"[{tag}] Running laxpcl1.e (pass 3, post-backshift)")
        pipeline.run_laxpcl1(p, laxpc1_path, self._log)

        bin_seconds = float(p.get("lc_bin_seconds") or 1.0)

        self._check_stop()
        self.stage.emit(f"[{tag}] Running lcurve ({bin_seconds:g}s bins)")
        lc_name = f"{self.file_name}_{label_suffix}.lc"
        lc_path = pipeline.run_lcurve(
            p, laxpc1_path, lc_name, self._log,
            target_bin_seconds=bin_seconds,
        )

        self.stage.emit(f"[{tag}] Plotting lightcurve")
        png_path = os.path.join(out_dir, f"{self.file_name}_{label_suffix}_lightcurve.png")
        pipeline.plot_lightcurve(
            lc_path, png_path, f"{self.source_name} ({label_suffix})", self._log,
        )

        if tag == "combined":
            self.combined_ready.emit(lc_path, out_dir)

        # copy the raw lightcurve fits + gti file into this run's output
        # folder too
        shutil.copy2(lc_path, out_dir)
        shutil.copy2(gti_inp, out_dir)

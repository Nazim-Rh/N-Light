import json
import os
import sys

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QToolButton, QFileDialog, QTextEdit, QMessageBox,
    QScrollArea, QDialog, QListView, QTreeView, QAbstractItemView, QSplitter,
    QStackedWidget,
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QIcon, QPalette, QColor

from .defaults import DEFAULTS
from .settings_dialog import SettingsDialog
from .worker import PipelineWorker
from . import lc_io
from .mode_pages import InspectPage

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", "n-light")
CONFIG_PATH = os.path.join(CONFIG_DIR, "settings.json")


def _icon_path():
    """
    Find ui/N-Light.png. N-Light.sh sets NLIGHT_ICON_PATH when it finds
    the file next to itself; fall back to looking relative to this file
    (N-Light/main.py -> ../ui/N-Light.png) in case main.py is ever
    run directly instead of via N-Light.sh. Returns None if not found.
    """
    env_path = os.environ.get("NLIGHT_ICON_PATH")
    if env_path and os.path.isfile(env_path):
        return env_path
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(os.path.dirname(here), "ui", "N-Light.png")
    if os.path.isfile(candidate):
        return candidate
    return None

# -- theme -----------------------------------------------------------------
# Dark blue color scheme, applied app-wide.
BG_MAIN = "#0E1118"        # Main background
BG_PANEL = "#10131B"       # Secondary background / panels
BG_INPUT = "#141923"       # Input background
BORDER = "#273256"         # Borders
ACCENT = "#5671C9"         # Primary accent
ACCENT_BRIGHT = "#7092DB"  # Bright accent / focus
TEXT_PRIMARY = "#DEE6EA"   # Primary text
TEXT_SECONDARY = "#989EA4"  # Secondary text
TEXT_PLACEHOLDER = "#7289A7"  # Placeholder text
BTN_BG = "#273256"         # Button background
BTN_HOVER = "#5266A5"      # Hover / active (also used to fill the Run button)

STYLE_SHEET = f"""
QMainWindow, QDialog, QWidget {{
    background-color: {BG_MAIN};
    color: {TEXT_PRIMARY};
    font-size: 13px;
}}
QLabel {{
    color: {TEXT_PRIMARY};
    background: transparent;
}}
QLabel[secondary="true"] {{
    color: {TEXT_SECONDARY};
}}
QLineEdit, QTextEdit, QSpinBox, QDoubleSpinBox {{
    background-color: {BG_INPUT};
    color: {TEXT_PRIMARY};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 6px 10px;
    selection-background-color: {ACCENT};
    selection-color: {TEXT_PRIMARY};
}}
QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border: 1px solid {ACCENT_BRIGHT};
}}
QTextEdit {{
    font-family: Consolas, "Courier New", monospace;
}}
QPushButton {{
    background-color: {BTN_BG};
    color: {TEXT_PRIMARY};
    border: 1px solid {BORDER};
    border-radius: 5px;
    padding: 5px 14px;
}}
QPushButton:hover {{
    background-color: {BTN_HOVER};
    color: {TEXT_PRIMARY};
    border: 1px solid {ACCENT_BRIGHT};
}}
QPushButton:pressed {{
    background-color: {ACCENT};
    color: {TEXT_PRIMARY};
    border: 1px solid {ACCENT};
}}
QPushButton:disabled {{
    background-color: {BG_PANEL};
    color: #4a5266;
    border-color: {BORDER};
}}
QPushButton#runButton {{
    background-color: {BTN_HOVER};
    color: {BG_MAIN};
    border: 1px solid {BTN_HOVER};
    font-weight: bold;
    padding: 6px 22px;
}}
QPushButton#runButton:hover {{
    background-color: {ACCENT_BRIGHT};
    color: {BG_MAIN};
    border: 1px solid {ACCENT_BRIGHT};
}}
QPushButton#runButton:pressed {{
    background-color: {ACCENT};
    color: {BG_MAIN};
    border: 1px solid {ACCENT};
}}
QPushButton#runButton:disabled {{
    background-color: {BORDER};
    color: #6b7690;
    border-color: {BORDER};
}}
QPushButton#stopButton {{
    background-color: #7A2E2A;
    color: {TEXT_PRIMARY};
    border: 1px solid #7A2E2A;
    font-weight: bold;
    padding: 6px 16px;
}}
QPushButton#stopButton:hover {{
    background-color: #9C3A34;
    border: 1px solid #9C3A34;
}}
QPushButton#stopButton:pressed {{
    background-color: #6A2622;
    border: 1px solid #6A2622;
}}
QPushButton#stopButton:disabled {{
    background-color: {BG_PANEL};
    color: #4a5266;
    border-color: {BORDER};
}}
QToolButton {{
    background-color: transparent;
    color: {TEXT_PRIMARY};
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 3px;
    font-size: 16px;
}}
QToolButton:hover {{
    background-color: {ACCENT};
    color: {TEXT_PRIMARY};
    border: 1px solid {ACCENT_BRIGHT};
}}
QGroupBox {{
    border: 1px solid {BORDER};
    border-radius: 5px;
    margin-top: 14px;
    padding-top: 10px;
    font-weight: bold;
    background-color: {BG_PANEL};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 6px;
    color: {ACCENT_BRIGHT};
}}
QScrollArea {{
    border: 1px solid {BORDER};
    border-radius: 4px;
    background-color: {BG_PANEL};
}}
QScrollBar:vertical {{
    background: {BG_MAIN};
    width: 12px;
}}
QScrollBar::handle:vertical {{
    background: {ACCENT};
    border-radius: 4px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{
    background: {ACCENT_BRIGHT};
}}
QSplitter::handle {{
    background-color: {BORDER};
    width: 3px;
}}
QSplitter::handle:hover {{
    background-color: {ACCENT};
}}
QMessageBox QLabel {{
    color: {TEXT_PRIMARY};
}}
"""


def load_params() -> dict:
    params = dict(DEFAULTS)
    if os.path.isfile(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                saved = json.load(f)
            params.update(saved)
        except Exception:
            pass
    return params


def save_params(params: dict) -> None:
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(params, f, indent=2)


def select_multiple_directories(parent, caption, start_dir=""):
    """
    Native QFileDialog only allows selecting one directory at a time.
    This drops to the non-native Qt dialog and turns on multi-selection
    for its internal list/tree views, so the user can Ctrl/Shift-click
    (or Shift-select a range of) several orbit folders in one go.
    Returns a list of the selected directory paths (possibly empty).
    """
    dlg = QFileDialog(parent, caption, start_dir)
    dlg.setFileMode(QFileDialog.Directory)
    dlg.setOption(QFileDialog.DontUseNativeDialog, True)
    dlg.setOption(QFileDialog.ShowDirsOnly, True)

    for view in dlg.findChildren((QListView, QTreeView)):
        view.setSelectionMode(QAbstractItemView.ExtendedSelection)

    if dlg.exec_() == QDialog.Accepted:
        return [p for p in dlg.selectedFiles() if p]
    return []


def readme_text() -> str:
    """
    README.txt is shipped inside .transient/ (next to the N-Light/
    package) so it survives installer/install.sh, which copies the whole
    .transient/ directory to the install location. main.py lives at
    .../N-Light/main.py, so the file is one directory up from here.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(os.path.dirname(here), "README.txt")
    if os.path.isfile(candidate):
        try:
            with open(candidate, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            pass
    return (
        "N-Light\n=======\n\n"
        "README.txt could not be found alongside the installed app.\n"
        "1. Enter a source/folder name.\n"
        "2. Use \"Add Orbit\" to add one or more orbit folders "
        "(multi-select is supported).\n"
        "3. Press \"Run\", review Settings, then \"Proceed\".\n"
        "4. Output is written under your configured output base path."
    )


class ReadmeDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("N-Light - Readme")
        self.resize(640, 560)
        layout = QVBoxLayout(self)

        view = QTextEdit()
        view.setReadOnly(True)
        view.setPlainText(readme_text())
        layout.addWidget(view)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)


class OrbitRow(QWidget):
    def __init__(self, on_remove, on_change, parent=None):
        super().__init__(parent)
        self.on_change = on_change
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Path to orbit folder...")
        browse = QPushButton("Browse...")
        remove = QPushButton("Remove")
        remove.setFixedWidth(80)

        browse.clicked.connect(self._browse)
        remove.clicked.connect(lambda: on_remove(self))
        self.edit.editingFinished.connect(lambda: self.on_change(self))

        layout.addWidget(self.edit)
        layout.addWidget(browse)
        layout.addWidget(remove)

    def _browse(self):
        path = QFileDialog.getExistingDirectory(self, "Choose orbit folder", self.edit.text())
        if path:
            self.edit.setText(path)
            self.on_change(self)

    def path(self) -> str:
        return self.edit.text().strip()

    def set_path(self, path: str):
        self.edit.setText(path)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("N-Light")
        self.resize(1020, 660)
        icon_path = _icon_path()
        if icon_path:
            self.setWindowIcon(QIcon(icon_path))

        self.params = load_params()
        self.orbit_rows = []
        self.worker = None

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # -- Top bar: title + settings / readme icons ---------------------
        top_bar = QHBoxLayout()
        title = QLabel("N-Light")
        title_font = QFont()
        title_font.setPointSize(15)
        title_font.setBold(True)
        title.setFont(title_font)
        top_bar.addWidget(title)
        top_bar.addStretch(1)

        self.settings_btn = QToolButton()
        self.settings_btn.setText("\u2699")  # gear
        self.settings_btn.setToolTip("Settings")
        self.settings_btn.clicked.connect(self.open_settings)
        top_bar.addWidget(self.settings_btn)

        self.readme_btn = QToolButton()
        self.readme_btn.setText("\U0001F4D8")  # book
        self.readme_btn.setToolTip("Readme")
        self.readme_btn.clicked.connect(self.open_readme)
        top_bar.addWidget(self.readme_btn)

        root.addLayout(top_bar)

        # -- Mode nav: N-lighter <-> Inspecter --------------------------
        # Inspecter is always reachable: a lightcurve can be handed to
        # it after a N-lighter run, or opened directly from disk
        # without running anything first.
        mode_bar = QHBoxLayout()
        self.mode_btns = {}
        for i, mode_name in enumerate(("N-lighter", "Inspecter")):
            btn = QPushButton(mode_name)
            btn.setCheckable(True)
            btn.clicked.connect(lambda _checked, idx=i: self.set_mode(idx))
            mode_bar.addWidget(btn)
            self.mode_btns[i] = btn
        mode_bar.addStretch(1)
        root.addLayout(mode_bar)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, stretch=1)

        lightcurve_page = QWidget()
        lc_page_layout = QVBoxLayout(lightcurve_page)
        lc_page_layout.setContentsMargins(0, 0, 0, 0)

        # -- Dashboard: left = paths/config, right = log -------------------
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(4)

        # Left panel: source name, orbit paths, run button
        left_panel = QWidget()
        left_panel.setObjectName("leftPanel")
        left_panel.setStyleSheet(
            f"QWidget#leftPanel {{ background-color: {BG_PANEL}; "
            f"border: 1px solid {BORDER}; border-radius: 6px; }}"
        )
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(12, 12, 12, 12)
        left_layout.setSpacing(8)

        left_layout.addWidget(QLabel("Source / folder name:"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("e.g. EXO0748-676")
        left_layout.addWidget(self.name_edit)

        # Orbit list header: orbit count on the left, Add Orbit on the right
        orbit_header = QHBoxLayout()
        self.orbit_count_label = QLabel("Orbits: 0")
        orbit_header.addWidget(self.orbit_count_label)
        orbit_header.addStretch(1)
        add_btn = QPushButton("Add Orbit")
        add_btn.clicked.connect(self.on_add_path_clicked)
        orbit_header.addWidget(add_btn)
        left_layout.addLayout(orbit_header)

        self.orbit_list_widget = QWidget()
        self.orbit_list_layout = QVBoxLayout(self.orbit_list_widget)
        self.orbit_list_layout.setContentsMargins(0, 0, 0, 0)
        self.orbit_list_layout.setSpacing(6)
        self.orbit_list_layout.setAlignment(Qt.AlignTop)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.orbit_list_widget)
        left_layout.addWidget(scroll, stretch=1)

        self._new_orbit_row()  # start with one empty field
        self._update_orbit_count()

        # Run button -- filled with the medium-blue "hover/active" color,
        # dark text, so it stands out as the primary action on the panel.
        # Stop sits right next to it, disabled until a run is active.
        run_row = QHBoxLayout()
        run_row.addStretch(1)
        self.run_btn = QPushButton("Run")
        self.run_btn.setObjectName("runButton")
        self.run_btn.setMinimumHeight(34)
        self.run_btn.setMinimumWidth(120)
        self.run_btn.clicked.connect(self.on_run_clicked)
        run_row.addWidget(self.run_btn)

        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setObjectName("stopButton")
        self.stop_btn.setMinimumHeight(34)
        self.stop_btn.setMinimumWidth(80)
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.on_stop_clicked)
        run_row.addWidget(self.stop_btn)

        left_layout.addLayout(run_row)

        self.splitter.addWidget(left_panel)

        # Right panel: log
        right_panel = QWidget()
        right_panel.setObjectName("rightPanel")
        right_panel.setStyleSheet(
            f"QWidget#rightPanel {{ background-color: {BG_PANEL}; "
            f"border: 1px solid {BORDER}; border-radius: 6px; }}"
        )
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(12, 12, 12, 12)
        right_layout.setSpacing(8)

        log_header = QHBoxLayout()
        log_header.addWidget(QLabel("Log"))
        log_header.addStretch(1)
        self.copy_log_btn = QPushButton("Copy")
        self.copy_log_btn.setFixedWidth(80)
        self.copy_log_btn.clicked.connect(self.copy_log)
        log_header.addWidget(self.copy_log_btn)
        right_layout.addLayout(log_header)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        right_layout.addWidget(self.log_view, stretch=1)

        self.splitter.addWidget(right_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 1)
        self._splitter_initialized = False

        lc_page_layout.addWidget(self.splitter, stretch=1)
        self.stack.addWidget(lightcurve_page)          # index 0 -- N-lighter

        self.inspect_page = InspectPage()
        self.stack.addWidget(self.inspect_page)          # index 1 -- Inspecter

        self._combined_out_dir = None
        self.set_mode(0)

    def showEvent(self, event):
        super().showEvent(event)
        # The splitter has no real width until the window is actually shown,
        # so a 50:50 setSizes() call in __init__ gets ignored/overridden by
        # child size hints. Do it once here, on first show, instead.
        if not self._splitter_initialized and self.splitter.width() > 0:
            half = self.splitter.width() // 2
            self.splitter.setSizes([half, self.splitter.width() - half])
            self._splitter_initialized = True

    # -- orbit rows ---------------------------------------------------

    def _new_orbit_row(self) -> OrbitRow:
        row = OrbitRow(self.remove_orbit_row, self.on_orbit_row_changed)
        self.orbit_rows.append(row)
        self.orbit_list_layout.addWidget(row)
        return row

    def remove_orbit_row(self, row):
        if len(self.orbit_rows) <= 1:
            row.set_path("")
            self._update_orbit_count()
            return  # keep at least one field
        self.orbit_rows.remove(row)
        row.setParent(None)
        row.deleteLater()
        self._update_orbit_count()

    def on_orbit_row_changed(self, row):
        self._update_orbit_count()
        path = row.path()
        if not path:
            return
        others = [r.path() for r in self.orbit_rows if r is not row and r.path()]
        if path in others:
            QMessageBox.warning(self, "Already added", f"'{path}' is already added.")

    def _update_orbit_count(self):
        n = len([r for r in self.orbit_rows if r.path()])
        self.orbit_count_label.setText(f"Orbits: {n}")

    def on_add_path_clicked(self):
        start_dir = ""
        for r in reversed(self.orbit_rows):
            if r.path():
                start_dir = os.path.dirname(r.path())
                break
        paths = select_multiple_directories(self, "Choose orbit folder(s)", start_dir)
        if not paths:
            return
        self._add_paths(paths)

    def _add_paths(self, paths):
        existing = {r.path() for r in self.orbit_rows if r.path()}
        dupes = []
        for p in paths:
            p = p.strip()
            if not p:
                continue
            if p in existing:
                dupes.append(p)
                continue
            existing.add(p)

            # Reuse the first empty field if there is one, otherwise
            # create a new field -- so a multi-select of folders 1, 2, 3
            # lands in three separate fields, same as adding them one
            # at a time with "Add Orbit".
            target_row = next((r for r in self.orbit_rows if not r.path()), None)
            if target_row is None:
                target_row = self._new_orbit_row()
            target_row.set_path(p)

        self._update_orbit_count()
        if dupes:
            listed = "\n".join(dupes)
            QMessageBox.warning(self, "Already added", f"Already added:\n{listed}")

    # -- settings / readme ---------------------------------------------

    def open_settings(self):
        dlg = SettingsDialog(self.params, self)
        if dlg.exec_() == SettingsDialog.Accepted:
            self.params = dlg.get_values()
            save_params(self.params)
            self.log("Settings updated.")

    def open_readme(self):
        ReadmeDialog(self).exec_()

    # -- log -------------------------------------------------------------

    def log(self, msg: str):
        self.log_view.append(msg)

    def copy_log(self):
        QApplication.clipboard().setText(self.log_view.toPlainText())
        self.copy_log_btn.setText("Copied!")
        QTimer.singleShot(1200, lambda: self.copy_log_btn.setText("Copy"))

    # -- run -------------------------------------------------------------

    def on_run_clicked(self):
        source_name = self.name_edit.text().strip()
        if not source_name:
            QMessageBox.warning(self, "Missing name", "Enter a source/folder name first.")
            return

        orbit_dirs = [r.path() for r in self.orbit_rows if r.path()]
        if not orbit_dirs:
            QMessageBox.warning(self, "No orbits", "Add at least one orbit folder path.")
            return

        dlg = SettingsDialog(self.params, self)
        if dlg.exec_() != SettingsDialog.Accepted:
            self.log("Cancelled at settings dialog.")
            return

        self.params = dlg.get_values()
        save_params(self.params)

        self.log_view.clear()
        self.run_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log(f"Starting run for '{source_name}' with {len(orbit_dirs)} orbit(s)...")

        self.worker = PipelineWorker(orbit_dirs, source_name, self.params)
        self.worker.log_line.connect(self.log)
        self.worker.stage.connect(lambda s: self.log(f"--- {s} ---"))
        self.worker.backshift_result.connect(self.on_backshift_result)
        self.worker.combined_ready.connect(self.on_combined_ready)
        self.worker.finished_ok.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.stopped.connect(self.on_stopped)
        self.worker.start()

    def on_stop_clicked(self):
        if self.worker is None or not self.worker.isRunning():
            return
        self.stop_btn.setEnabled(False)
        self.log("\nStopping... (killing the current process)")
        self.worker.request_stop()

    # -- modes -------------------------------------------------------------

    def set_mode(self, index: int):
        if not self.mode_btns[index].isEnabled():
            return
        self.stack.setCurrentIndex(index)
        for i, btn in self.mode_btns.items():
            btn.setChecked(i == index)

    def on_combined_ready(self, lc_path: str, out_dir: str):
        try:
            series = lc_io.read_series(lc_path)
        except Exception as e:
            self.log(f"! Could not load lightcurve for Inspecter: {e}")
            return
        source_name = self.name_edit.text().strip()
        self._combined_out_dir = out_dir
        self.inspect_page.load(series, out_dir, source_name)
        self.log(f"\nLightcurve ready for Inspecter ({len(series)} points).")

    def on_backshift_result(self, result: dict):
        tag = result.get("tag")
        parts = []
        if "response_file" in result:
            parts.append(f"Response file: {result['response_file']}")
        if "gain_offset_kev" in result:
            parts.append(f"Gain offset: {result['gain_offset_kev']} keV")
        if "suggested_background" in result:
            parts.append(f"Suggestion: try background {result['suggested_background']}")
        if parts:
            prefix = f"[{tag}] " if tag else ""
            self.log(f"{prefix}backshiftv3.e result -> " + " | ".join(parts))
            self.log(
                "(If you want to try a different background epoch, edit back4.inp "
                "in the LAXPC1 dir and re-run manually, then re-run N-Light.)"
            )

    def on_finished(self, out_dir: str):
        self.run_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.log(f"\nDone. Output saved to: {out_dir}")
        self.log("  combined/  -> all selected orbits reduced together")
        self.log("  <orbit>/   -> one folder per orbit (only when >1 orbit was run)")
        self.log("N-Lightened successfully!")
        QMessageBox.information(
            self, "N-Lightened successfully",
            f"N-Lightened successfully!\n\n"
            f"Lightcurve and GTI plots saved to:\n{out_dir}\n\n"
            "(combined/ has the all-orbit lightcurve; each orbit also gets "
            "its own subfolder when more than one orbit was run.)"
        )

    def on_failed(self, msg: str):
        self.run_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        QMessageBox.critical(self, "Run failed", msg)

    def on_stopped(self):
        self.run_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE_SHEET)
    palette = app.palette()
    palette.setColor(QPalette.PlaceholderText, QColor(TEXT_PLACEHOLDER))
    app.setPalette(palette)
    icon_path = _icon_path()
    if icon_path:
        app.setWindowIcon(QIcon(icon_path))  # taskbar / window-switcher icon
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

"""
mode_pages.py -- the Inspecter page (merged Outburst + Eclipse mode).

Outburst and Eclipse mode used to be two separate, sequential pages
that did exactly the same thing (load/open a lightcurve, adjust its
bin size, select a time range, crop it into "selected" + "removed"
lightcurves). They're now one page -- Inspecter -- always reachable
from the mode bar, with a switch that decides whether crops are
saved/labelled as "outburst" or "eclipse". It knows nothing about the
laxpcsoft/lcurve pipeline -- it only works on Series objects already
produced by it (see lc_io.py), or opened directly from disk.
"""

import os
from typing import List, Optional, Tuple

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit,
    QSlider, QDoubleSpinBox, QMessageBox, QFileDialog, QButtonGroup,
)

from . import lc_io
from .interactive_plot import LightcurveView


class InspectPage(QWidget):
    """
    Inspecter: load/open a lightcurve, adjust its bin size, select a
    time range (by clicking the curve or typing From/To), and crop it
    into "selected" + "removed" lightcurves saved under
    out_dir/<mode>s/. A switch decides whether the current mode is
    "outburst" or "eclipse" -- this only changes the filename suffix
    and log labelling, not the mechanics.

    Reachable at any time: a lightcurve can be handed to it after a
    N-lighter run (see load()), or opened directly from disk with
    "Open .lc file..." without running anything first.
    """

    MODES = ("outburst", "eclipse")
    DEFAULT_BIN_SECONDS = 1.0
    BIN_DECIMALS = 2

    def __init__(self, parent=None):
        super().__init__(parent)
        self.out_dir: str = ""
        self.source_name: str = ""
        self.mode: str = self.MODES[0]
        self.base_series: Optional[lc_io.Series] = None  # as loaded, never rebinned in place
        self.working: Optional[lc_io.Series] = None        # currently displayed (rebinned + crops applied)
        self.removed_ranges: List[Tuple[float, float]] = []
        self._crop_count = 0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # -- currently loaded lightcurve name -------------------------
        self.lc_name_label = QLabel("No lightcurve selected")
        self.lc_name_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.lc_name_label)

        top_row = QHBoxLayout()
        self.open_btn = QPushButton("Open .lc file...")
        self.open_btn.clicked.connect(self.open_lc_file)
        top_row.addWidget(self.open_btn)

        top_row.addSpacing(12)
        top_row.addWidget(QLabel("Mode:"))
        self.outburst_btn = QPushButton("Outburst")
        self.eclipse_btn = QPushButton("Eclipse")
        for btn, mode in ((self.outburst_btn, "outburst"), (self.eclipse_btn, "eclipse")):
            btn.setCheckable(True)
            btn.clicked.connect(lambda _checked, m=mode: self._set_mode(m))
            top_row.addWidget(btn)
        self.mode_group = QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.mode_group.addButton(self.outburst_btn)
        self.mode_group.addButton(self.eclipse_btn)
        self.outburst_btn.setChecked(True)

        top_row.addSpacing(12)
        top_row.addWidget(QLabel("Bin size (s):"))
        self.bin_spin = QDoubleSpinBox()
        self.bin_spin.setDecimals(self.BIN_DECIMALS)
        self.bin_spin.setMinimum(0.01)
        self.bin_spin.setMaximum(1.0)
        self.bin_spin.setValue(self.DEFAULT_BIN_SECONDS)
        self.bin_spin.valueChanged.connect(self._on_bin_changed)
        top_row.addWidget(self.bin_spin)
        top_row.addStretch(1)
        layout.addLayout(top_row)

        self.range_label = QLabel("Time range: --")
        self.range_label.setStyleSheet("color: #989EA4;")
        layout.addWidget(self.range_label)

        self.view = LightcurveView()
        self.view.selectionChanged.connect(self._on_selection_changed)
        layout.addWidget(self.view, stretch=3)

        # -- pan controls: handy for both modes on long lightcurves ---
        pan_row = QHBoxLayout()
        self.left_btn = QPushButton("\u25C0 Pan left")
        self.right_btn = QPushButton("Pan right \u25B6")
        self.left_btn.clicked.connect(lambda: self.view.pan_by_fraction(-0.2))
        self.right_btn.clicked.connect(lambda: self.view.pan_by_fraction(0.2))
        pan_row.addWidget(self.left_btn)
        self.pan_slider = QSlider(Qt.Horizontal)
        self.pan_slider.setMinimum(0)
        self.pan_slider.setMaximum(1000)
        self.pan_slider.setValue(0)
        self.pan_slider.valueChanged.connect(
            lambda v: self.view.pan_to_center_fraction(v / 1000.0)
        )
        pan_row.addWidget(self.pan_slider, stretch=1)
        pan_row.addWidget(self.right_btn)
        layout.addLayout(pan_row)

        sel_row = QHBoxLayout()
        sel_row.addWidget(QLabel("From:"))
        self.from_spin = QDoubleSpinBox()
        self.from_spin.setDecimals(3)
        self.from_spin.setRange(-1e12, 1e12)
        sel_row.addWidget(self.from_spin)
        sel_row.addWidget(QLabel("To:"))
        self.to_spin = QDoubleSpinBox()
        self.to_spin.setDecimals(3)
        self.to_spin.setRange(-1e12, 1e12)
        sel_row.addWidget(self.to_spin)
        self.select_range_btn = QPushButton("Select Range")
        self.select_range_btn.clicked.connect(self._on_select_range_clicked)
        sel_row.addWidget(self.select_range_btn)
        sel_row.addStretch(1)
        layout.addLayout(sel_row)

        actions = QHBoxLayout()
        self.crop_btn = QPushButton("Crop selected")
        self.crop_btn.setEnabled(False)
        self.crop_btn.clicked.connect(self.crop_selection)
        actions.addWidget(self.crop_btn)
        actions.addStretch(1)
        layout.addLayout(actions)

        self.log_label = QLabel("Log:")
        layout.addWidget(self.log_label)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumHeight(120)
        layout.addWidget(self.log_view)

        self._update_mode_labels()

    # -- mode switch (outburst / eclipse) -------------------------------

    def _set_mode(self, mode: str):
        if mode not in self.MODES or mode == self.mode:
            return
        self.mode = mode
        self._update_mode_labels()

    def _update_mode_labels(self):
        self.crop_btn.setText(f"Crop selected ({self.mode})")
        self.log_label.setText(f"{self.mode.capitalize()} log:")

    # -- loading -----------------------------------------------------------

    def load(self, series: lc_io.Series, out_dir: str, source_name: str):
        self.out_dir = out_dir
        self.source_name = source_name or "source"
        self.log_view.clear()
        self._set_base_series(series)
        self._log(f"Loaded lightcurve ({len(series)} points, "
                   f"{series.duration():.1f}s span).")

    def open_lc_file(self):
        start_dir = self.out_dir or os.path.expanduser("~")
        path, _ = QFileDialog.getOpenFileName(
            self, "Open lightcurve", start_dir, "Lightcurve files (*.lc *.fits *.fits.gz);;All files (*)"
        )
        if not path:
            return
        try:
            series = lc_io.read_series(path)
        except Exception as e:
            QMessageBox.critical(self, "Could not open file", str(e))
            return

        if not self.out_dir:
            self.out_dir = os.path.dirname(path)
        if not self.source_name:
            self.source_name = os.path.splitext(os.path.basename(path))[0]

        self.log_view.clear()
        self._set_base_series(series)
        self._log(f"Opened {path} ({len(series)} points, {series.duration():.1f}s span).")

    def _set_base_series(self, series: lc_io.Series):
        self.base_series = series
        self.removed_ranges = []
        self._crop_count = 0

        name = os.path.basename(series.source_path) if series.source_path else "(unsaved)"
        self.lc_name_label.setText(f"Lightcurve: {name}")

        min_bin = series.bin_seconds or 0.01
        limit = lc_io.max_reasonable_bin_seconds(series)

        self.bin_spin.blockSignals(True)
        self.bin_spin.setMinimum(min_bin)
        self.bin_spin.setMaximum(max(min_bin, limit))
        self.bin_spin.setValue(max(min_bin, min(self.DEFAULT_BIN_SECONDS, limit)))
        self.bin_spin.blockSignals(False)

        self._rebuild_working()

    def _log(self, msg: str):
        self.log_view.append(msg)

    # -- bin size / rebuilding ------------------------------------------

    def _on_bin_changed(self, _value: float):
        self._rebuild_working()

    def _rebuild_working(self):
        if self.base_series is None:
            return
        bin_seconds = float(self.bin_spin.value())
        native = self.base_series.bin_seconds or bin_seconds
        working = (self.base_series if abs(bin_seconds - native) < 1e-9
                   else lc_io.rebin_series(self.base_series, bin_seconds))
        working.source_path = self.base_series.source_path

        for (x1, x2) in self.removed_ranges:
            _, working = lc_io.crop_series(working, x1, x2)

        self.working = working
        self.view.set_series(
            self.working,
            title=f"{self.source_name} -- Inspecter ({bin_seconds:g}s bins)",
        )
        self._update_range_label()

    def _update_range_label(self):
        if self.working is None or len(self.working) == 0:
            self.range_label.setText("Time range: --")
            return
        t = self.working.time
        start, stop = float(t.min()), float(t.max())
        self.range_label.setText(
            f"Time range: {start:.3f} s -- {stop:.3f} s  (duration {stop - start:.3f} s)"
        )
        # keep the From/To fields inside the currently visible span
        self.from_spin.setRange(start, stop)
        self.to_spin.setRange(start, stop)

    # -- selection ---------------------------------------------------------

    def _on_selection_changed(self, x1, x2):
        self.crop_btn.setEnabled(bool(x1 >= 0 and x2 >= 0 and x1 != x2))
        if x1 >= 0 and x2 >= 0:
            self.from_spin.blockSignals(True)
            self.to_spin.blockSignals(True)
            self.from_spin.setValue(x1)
            self.to_spin.setValue(x2)
            self.from_spin.blockSignals(False)
            self.to_spin.blockSignals(False)

    def _on_select_range_clicked(self):
        x1, x2 = self.from_spin.value(), self.to_spin.value()
        if x1 == x2:
            QMessageBox.warning(self, "Invalid range", "From and To must be different times.")
            return
        self.view.set_selection(x1, x2)

    # -- crop ----------------------------------------------------------

    def crop_selection(self):
        if self.working is None:
            return
        sel = self.view.get_selection()
        if sel is None:
            return
        x1, x2 = sel
        self._crop_count += 1
        n = self._crop_count

        inside, outside = lc_io.crop_series(self.working, x1, x2)
        if len(inside) == 0:
            QMessageBox.warning(self, "Empty selection",
                                 "No data points fall inside the selected range.")
            self._crop_count -= 1
            return

        label = self.mode
        crop_dir = os.path.join(self.out_dir, f"{label}s")
        sel_lc = os.path.join(crop_dir, f"{label}_{n:02d}_selected.lc")
        sel_png = os.path.join(crop_dir, f"{label}_{n:02d}_selected.png")
        rem_lc = os.path.join(crop_dir, f"{label}_{n:02d}_removed.lc")
        rem_png = os.path.join(crop_dir, f"{label}_{n:02d}_removed.png")

        lc_io.write_series(inside, sel_lc, template_path=self.working.source_path)
        lc_io.save_png(inside, sel_png, title=f"{self.source_name} -- {label} {n} (selected)")
        lc_io.write_series(outside, rem_lc, template_path=self.working.source_path)
        lc_io.save_png(outside, rem_png, title=f"{self.source_name} -- {label} {n} removed")

        self._log(f"{label.capitalize()} {n}: x = [{x1:.4g}, {x2:.4g}]  "
                   f"selected -> {sel_lc}  |  removed -> {rem_lc}")

        self.removed_ranges.append((x1, x2))
        self.working = outside
        self.working.source_path = rem_lc
        self.view.set_series(self.working, title=f"{self.source_name} -- "
                              f"after removing {n} {label}(s)")
        self._update_range_label()

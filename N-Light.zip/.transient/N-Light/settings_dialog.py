from PyQt5.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QSpinBox, QDoubleSpinBox, QPushButton,
    QHBoxLayout, QVBoxLayout, QLabel, QFileDialog, QGroupBox, QScrollArea,
    QWidget,
)


class SettingsDialog(QDialog):
    """
    Shows every editable pipeline parameter, pre-filled with the current
    values (defaults on first run, or whatever was saved before).
    Pressing "Proceed" accepts the dialog and the caller reads back
    .get_values(). Pressing "Cancel" aborts the run.
    """

    def __init__(self, params: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("N-Light - Settings")
        self.setMinimumWidth(520)
        self._params = dict(params)
        self._fields = {}

        outer = QVBoxLayout(self)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        scroll.setWidget(inner)
        form_container = QVBoxLayout(inner)

        form_container.addWidget(self._path_group())
        form_container.addWidget(self._laxpcl1_group())
        form_container.addWidget(self._backshift_group())
        form_container.addWidget(self._lcurve_group())

        outer.addWidget(scroll)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        proceed_btn = QPushButton("Proceed")
        proceed_btn.setDefault(True)
        proceed_btn.clicked.connect(self._on_proceed)
        btn_row.addStretch(1)
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(proceed_btn)
        outer.addLayout(btn_row)

    # -- field builders ----------------------------------------------

    def _line(self, key, label_text, form):
        edit = QLineEdit(str(self._params.get(key, "")))
        self._fields[key] = ("str", edit)
        form.addRow(label_text, edit)
        return edit

    def _path_line(self, key, label_text, form, is_dir=True):
        row = QHBoxLayout()
        edit = QLineEdit(str(self._params.get(key, "")))
        browse = QPushButton("Browse...")

        def do_browse():
            if is_dir:
                path = QFileDialog.getExistingDirectory(self, f"Choose {label_text}", edit.text())
            else:
                path, _ = QFileDialog.getOpenFileName(self, f"Choose {label_text}", edit.text())
            if path:
                edit.setText(path)

        browse.clicked.connect(do_browse)
        row.addWidget(edit)
        row.addWidget(browse)
        self._fields[key] = ("str", edit)
        wrapper = QWidget()
        wrapper.setLayout(row)
        form.addRow(label_text, wrapper)
        return edit

    def _int(self, key, label_text, form, minv=-100000, maxv=100000):
        box = QSpinBox()
        box.setRange(minv, maxv)
        box.setValue(int(self._params.get(key, 0) or 0))
        self._fields[key] = ("int", box)
        form.addRow(label_text, box)
        return box

    def _float(self, key, label_text, form, minv=-100000.0, maxv=100000.0, decimals=3):
        box = QDoubleSpinBox()
        box.setDecimals(decimals)
        box.setRange(minv, maxv)
        box.setValue(float(self._params.get(key, 0.0) or 0.0))
        self._fields[key] = ("float", box)
        form.addRow(label_text, box)
        return box

    # -- groups ---------------------------------------------------------

    def _path_group(self):
        box = QGroupBox("Paths")
        form = QFormLayout(box)
        self._path_line("laxpc1_path", "LAXPC1 software dir (eclipse_gti)", form, is_dir=True)
        self._path_line("output_base_path", "Output base path", form, is_dir=True)
        return box

    def _laxpcl1_group(self):
        box = QGroupBox("laxpcl1.e parameters")
        form = QFormLayout(box)
        self._int("lxp", "LAXPC unit (lxp)", form, 1, 3)
        self._float("tbin", "Time bin (tbin)", form, 0.0001, 10000.0)
        self._int("anode", "Anode", form, 0, 20)
        self._int("chan_min", "Channel range: min", form, 0, 1023)
        self._int("chan_max", "Channel range: max", form, 0, 1023)
        self._int("nchan_spectrum", "No. of channels in spectrum", form, 1, 1024)
        self._int("uld_bin", "ULD bin", form, -10, 1023)
        self._int("earth_occ", "Earth occultation flag", form, -10, 10)
        self._int("event_flag", "Event flag", form, -10, 10)
        self._int("laxpc_unit", "File-discovery LAXPC unit (lxp<N> folder)", form, 1, 3)
        return box

    def _backshift_group(self):
        box = QGroupBox("backshiftv3.e parameters")
        form = QFormLayout(box)
        self._int("backshift_idi", "idi", form, 0, 10)
        self._int("backshift_timebin", "Time-bin", form, 0, 10000)
        self._int("backshift_nul", "nul", form, -10, 10)
        self._line("pha_filename", "PHA output filename (blank = default)", form)
        return box

    def _lcurve_group(self):
        box = QGroupBox("lcurve parameters")
        form = QFormLayout(box)
        self._line("lcurve_series_file", "Series filename", form)
        self._float("lc_bin_seconds", "Bin size (s)", form, 0.001, 100000.0, decimals=3)
        self._line("lcurve_newbins_per_interval", "Newbins/Interval (blank = default)", form)
        return box

    # -- result -----------------------------------------------------

    def _on_proceed(self):
        self.accept()

    def get_values(self) -> dict:
        out = dict(self._params)
        for key, (kind, widget) in self._fields.items():
            if kind == "str":
                out[key] = widget.text().strip()
            elif kind == "int":
                out[key] = widget.value()
            elif kind == "float":
                out[key] = widget.value()
        return out

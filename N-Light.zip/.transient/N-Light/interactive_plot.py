"""
interactive_plot.py -- the shared interactive lightcurve widget used by
both Outburst mode and Eclipse mode.

Built on pyqtgraph rather than matplotlib because it's the piece that
actually needs to be interactive in real time: mouse-wheel/drag zoom,
a crosshair that tracks the cursor and reports data coordinates, and
click-to-select two x-points for cropping, all while staying smooth on
lightcurves with tens of thousands of points.
"""

from typing import List, Optional

import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton

from .lc_io import Series, with_gap_breaks

pg.setConfigOptions(antialias=True, background="k", foreground="w")


class LightcurveView(QWidget):
    """
    Displays one Series as a black-background plot: a single connected
    white line (no per-point markers) plus a translucent white band for
    the uncertainty. Supports:

      - hover crosshair (dashed, both axes) with a live x/y readout
      - mouse-wheel / drag zoom & pan (pyqtgraph default), plus
        explicit Zoom In / Zoom Out / Reset View buttons
      - click-to-select up to two x points (drawn as dashed selection
        markers); selectionChanged(x1, x2) fires once both are set

    selectionChanged(-1, -1) is emitted when the selection is cleared.
    """

    selectionChanged = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._series: Optional[Series] = None
        self._selected_x: List[float] = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # -- toolbar: zoom controls + readout + selection controls -----
        toolbar = QHBoxLayout()
        self.zoom_in_btn = QPushButton("Zoom In")
        self.zoom_out_btn = QPushButton("Zoom Out")
        self.reset_view_btn = QPushButton("Reset View")
        self.clear_sel_btn = QPushButton("Clear Selection")
        self.zoom_in_btn.clicked.connect(self.zoom_in)
        self.zoom_out_btn.clicked.connect(self.zoom_out)
        self.reset_view_btn.clicked.connect(self.reset_view)
        self.clear_sel_btn.clicked.connect(self.clear_selection)
        for b in (self.zoom_in_btn, self.zoom_out_btn, self.reset_view_btn, self.clear_sel_btn):
            toolbar.addWidget(b)
        toolbar.addStretch(1)
        self.readout = QLabel("x = --, y = --")
        self.readout.setStyleSheet("color: #DEE6EA;")
        toolbar.addWidget(self.readout)
        layout.addLayout(toolbar)

        self.sel_label = QLabel("Selected: none")
        self.sel_label.setStyleSheet("color: #989EA4;")
        layout.addWidget(self.sel_label)

        # -- plot --------------------------------------------------------
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground("k")
        self.plot_item = self.plot_widget.getPlotItem()
        self.plot_item.showGrid(x=False, y=False)
        self.plot_item.setLabel("bottom", "Time", units="s", color="w")
        self.plot_item.setLabel("left", "Rate", units="counts/s", color="w")
        for axis_name in ("bottom", "left", "top", "right"):
            axis = self.plot_item.getAxis(axis_name)
            axis.setPen(pg.mkPen("w"))
            axis.setTextPen(pg.mkPen("w"))

        white_pen = pg.mkPen(color="w", width=1.2)
        # connect="finite" breaks the line at NaNs, so gaps left by a
        # crop (an outburst/eclipse removed) show as a real break
        # instead of a straight line bridging over missing data.
        self.curve = self.plot_widget.plot([], [], pen=white_pen, symbol=None, connect="finite")
        self.err_upper = pg.PlotDataItem([], [])
        self.err_lower = pg.PlotDataItem([], [])
        self.err_band = pg.FillBetweenItem(
            self.err_upper, self.err_lower, brush=pg.mkBrush(255, 255, 255, 60)
        )
        self.plot_widget.addItem(self.err_band)

        # crosshair: dashed vertical + horizontal lines through the cursor
        dash_pen = pg.mkPen(color=(255, 255, 255, 160), width=1, style=Qt.DashLine)
        self.vline = pg.InfiniteLine(angle=90, movable=False, pen=dash_pen)
        self.hline = pg.InfiniteLine(angle=0, movable=False, pen=dash_pen)
        self.vline.setVisible(False)
        self.hline.setVisible(False)
        self.plot_widget.addItem(self.vline, ignoreBounds=True)
        self.plot_widget.addItem(self.hline, ignoreBounds=True)

        # selection markers (up to two dashed vertical lines)
        sel_pen = pg.mkPen(color=(255, 210, 80, 220), width=1.5, style=Qt.DashLine)
        self.sel_lines = [
            pg.InfiniteLine(angle=90, movable=False, pen=sel_pen),
            pg.InfiniteLine(angle=90, movable=False, pen=sel_pen),
        ]
        for ln in self.sel_lines:
            ln.setVisible(False)
            self.plot_widget.addItem(ln, ignoreBounds=True)

        self.plot_widget.scene().sigMouseMoved.connect(self._on_mouse_moved)
        self.plot_widget.scene().sigMouseClicked.connect(self._on_mouse_clicked)

        layout.addWidget(self.plot_widget, stretch=1)

    # -- data ----------------------------------------------------------

    def set_series(self, series: Series, title: str = ""):
        self._series = series
        self.clear_selection()
        t, r, e = with_gap_breaks(series)
        self.curve.setData(t, r, connect="finite")
        if e is not None and np.any(np.nan_to_num(e)):
            self.err_upper.setData(t, r + e, connect="finite")
            self.err_lower.setData(t, r - e, connect="finite")
            self.err_band.setVisible(True)
        else:
            self.err_band.setVisible(False)
        if title:
            self.plot_item.setTitle(title, color="w")
        if len(series.time):
            self.plot_widget.setXRange(float(series.time.min()), float(series.time.max()), padding=0.02)

    def series(self) -> Optional[Series]:
        return self._series

    # -- crosshair / readout --------------------------------------------

    def _on_mouse_moved(self, scene_pos):
        vb = self.plot_item.getViewBox()
        if not self.plot_item.sceneBoundingRect().contains(scene_pos):
            self.vline.setVisible(False)
            self.hline.setVisible(False)
            return
        pt = vb.mapSceneToView(scene_pos)
        x, y = pt.x(), pt.y()
        self.vline.setPos(x)
        self.hline.setPos(y)
        self.vline.setVisible(True)
        self.hline.setVisible(True)
        self.readout.setText(f"x = {x:.4g}, y = {y:.4g}")

    # -- point selection for cropping -----------------------------------

    def _on_mouse_clicked(self, ev):
        if ev.button() != Qt.LeftButton or self._series is None or len(self._series) == 0:
            return
        vb = self.plot_item.getViewBox()
        if not self.plot_item.sceneBoundingRect().contains(ev.scenePos()):
            return
        pt = vb.mapSceneToView(ev.scenePos())
        x = float(pt.x())
        # snap to the nearest actual sample time, so the crop boundary
        # lines up exactly with a real data point
        idx = int(np.argmin(np.abs(self._series.time - x)))
        snapped_x = float(self._series.time[idx])

        if len(self._selected_x) >= 2:
            self._selected_x = []
            for ln in self.sel_lines:
                ln.setVisible(False)

        self._selected_x.append(snapped_x)
        line = self.sel_lines[len(self._selected_x) - 1]
        line.setPos(snapped_x)
        line.setVisible(True)

        if len(self._selected_x) == 1:
            self.sel_label.setText(f"Selected: x1 = {snapped_x:.4g} (click a second point)")
            self.selectionChanged.emit(-1.0, -1.0)
        else:
            x1, x2 = sorted(self._selected_x)
            self.sel_label.setText(f"Selected: x1 = {x1:.4g}, x2 = {x2:.4g}")
            self.selectionChanged.emit(x1, x2)

    def set_selection(self, x1: float, x2: float):
        """
        Programmatically set the crop selection (e.g. from typed
        From/To fields) exactly as if the user had clicked those two
        x positions: draws both dashed selection lines and emits
        selectionChanged(x1, x2), same as a two-click selection.
        """
        self._selected_x = [float(x1), float(x2)]
        lo, hi = sorted(self._selected_x)
        self.sel_lines[0].setPos(lo)
        self.sel_lines[1].setPos(hi)
        for ln in self.sel_lines:
            ln.setVisible(True)
        self.sel_label.setText(f"Selected: x1 = {lo:.4g}, x2 = {hi:.4g}")
        self.selectionChanged.emit(lo, hi)

    def clear_selection(self):
        self._selected_x = []
        for ln in self.sel_lines:
            ln.setVisible(False)
        self.sel_label.setText("Selected: none")
        self.selectionChanged.emit(-1.0, -1.0)

    def get_selection(self):
        """Returns (x1, x2) sorted, or None if fewer than 2 points selected."""
        if len(self._selected_x) < 2:
            return None
        x1, x2 = sorted(self._selected_x)
        return x1, x2

    # -- zoom ------------------------------------------------------------

    def zoom_in(self):
        self.plot_item.getViewBox().scaleBy((0.7, 0.7))

    def zoom_out(self):
        self.plot_item.getViewBox().scaleBy((1 / 0.7, 1 / 0.7))

    def reset_view(self):
        if self._series is not None and len(self._series):
            t = self._series.time
            self.plot_widget.setXRange(float(t.min()), float(t.max()), padding=0.02)
            self.plot_item.enableAutoRange(axis="y")

    # -- panning (used by Eclipse mode's arrows/slider) -------------------

    def pan_by_fraction(self, fraction: float):
        """Shift the current visible x-range by `fraction` of its own
        width (negative = left, positive = right). Used for the left/
        right arrow buttons."""
        (x0, x1), _ = self.plot_item.getViewBox().viewRange()
        width = x1 - x0
        shift = width * fraction
        self.plot_widget.setXRange(x0 + shift, x1 + shift, padding=0)

    def pan_to_center_fraction(self, frac: float):
        """Move the current view so its center sits at `frac` (0..1) of
        the full data time span. Used by the Eclipse-mode slider for
        smooth continuous panning while zoomed in."""
        if self._series is None or len(self._series) == 0:
            return
        t = self._series.time
        full_lo, full_hi = float(t.min()), float(t.max())
        (x0, x1), _ = self.plot_item.getViewBox().viewRange()
        width = x1 - x0
        span = max(full_hi - full_lo - width, 0.0)
        new_lo = full_lo + span * max(0.0, min(1.0, frac))
        self.plot_widget.setXRange(new_lo, new_lo + width, padding=0)

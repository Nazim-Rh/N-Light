"""
Default settings for N-Light.

These defaults come straight from a real laxpcsoft run.txt session
(EXO 0748-676, AS1T05_213T01_9000006344). Every value here is editable
from the Settings dialog in the app -- nothing is hard-coded into the
pipeline logic itself.
"""

import os

DEFAULTS = {
    # ---- Paths -----------------------------------------------------
    # Directory that contains laxpcl1.e, backshiftv3.e, findfile,
    # back4.inp, gti.inp, makefile*, etc. (the "eclipse_gti" working
    # dir in the LAXPC1 layout). Must be editable -- differs per machine.
    "laxpc1_path": os.path.join(os.path.expanduser("~"), "LAXPC1", "eclipse_gti"),

    # Base directory where N-Light will create the per-source output
    # folder. Defaults to the user's home directory.
    "output_base_path": os.path.expanduser("~"),

    # ---- laxpcl1.e prompts ------------------------------------------
    # "Type lxp,tbin,anode [1 1.0 0]"
    "lxp": 2,
    "tbin": 1.0,
    "anode": 0,

    # "Type channel range for light curve [0 1023]"
    "chan_min": 28,
    "chan_max": 140,

    # "Type No. of channels in spectrum: 1024/512/256 [ 512 ]"
    "nchan_spectrum": 256,

    # "Type uld bin,Earth occultation, event flag [-1 1 2]"
    "uld_bin": -1,
    "earth_occ": 1,
    "event_flag": -2,

    # ---- backshiftv3.e prompts ---------------------------------------
    # "type lxp,anode,idi [1 0 0]" -- lxp/anode reuse the values above
    "backshift_idi": 0,

    # "Type time-bin, channel range for light curve, nul [1 0 1023 -1]"
    "backshift_timebin": 1,
    "backshift_nul": -1,

    # "type .pha file name [ lxp2level2back.pha ]" -- blank/"/" = default
    "pha_filename": "",

    # ---- findfile / file discovery -----------------------------------
    # Which LAXPC unit's BB/EA fits files to pick up per orbit
    # (matches the "lxp" value above by default: lxp2 -> unit 2)
    "laxpc_unit": 2,

    # ---- lcurve (HEASoft) prompts -------------------------------------
    "lcurve_series_file": "lxp2level2.evn",

    # The one bin size N-Light uses, in REAL SECONDS, for the lightcurve
    # it creates (this is what used to come out wrong: "1" here now
    # means an actual 1-second bin, not "group 1 raw bin"). N-Light
    # reads the input file's native bin time from lcurve's own output
    # and works out the right grouping count automatically -- see
    # run_lcurve() in pipeline.py. Inspecter starts from this same bin
    # size and lets you change it (and re-slice) on the fly.
    "lc_bin_seconds": 1.0,

    # leave blank to accept HEASoft's suggested Newbins/Interval
    "lcurve_newbins_per_interval": "",

    # ---- misc ----------------------------------------------------------
    # timeout (seconds) for each interactive step before we give up
    "step_timeout": 600,
}


def expand(path: str) -> str:
    return os.path.abspath(os.path.expanduser(path))

"""
lc_io.py -- lightweight lightcurve I/O + math for the interactive
Outburst and Eclipse modes.

These modes work on data that's already been produced by pipeline.py
(a .lc FITS file with a TIME/RATE*/ERROR* table). Rather than shelling
back out to HEASoft's lcurve for every crop/rebin the user does
interactively (slow, and needs HEASoft on PATH), everything here is
plain numpy + astropy so the GUI stays responsive.

A "series" is represented in-memory as a small dataclass of three
1-D numpy arrays (time, rate, err) plus the path it came from.
"""

import os
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np


@dataclass
class Series:
    time: np.ndarray
    rate: np.ndarray
    err: np.ndarray
    source_path: str = ""
    bin_seconds: Optional[float] = None

    def __len__(self):
        return len(self.time)

    def duration(self) -> float:
        if len(self.time) < 2:
            return 0.0
        return float(self.time[-1] - self.time[0])


def _find_column(names: List[str], preferred: str) -> Optional[str]:
    if preferred in names:
        return preferred
    candidates = sorted(n for n in names if n.startswith(preferred))
    return candidates[0] if candidates else None


def read_series(lc_fits_path: str) -> Series:
    """Read TIME/RATE*/ERROR* out of a .lc FITS file into a Series."""
    from astropy.io import fits
    with fits.open(lc_fits_path) as hdul:
        rate_hdu = hdul["RATE"] if "RATE" in hdul else hdul[1]
        data = rate_hdu.data
        time = np.asarray(data["TIME"], dtype=float)
        rate_col = _find_column(data.names, "RATE")
        if rate_col is None:
            raise KeyError(f"No RATE-like column found in {lc_fits_path}. Columns: {data.names}")
        rate = np.asarray(data[rate_col], dtype=float)
        err_col = _find_column(data.names, "ERROR")
        err = np.asarray(data[err_col], dtype=float) if err_col else np.zeros_like(rate)

    order = np.argsort(time)
    time, rate, err = time[order], rate[order], err[order]
    bin_seconds = float(np.median(np.diff(time))) if len(time) > 1 else None
    return Series(time=time, rate=rate, err=err, source_path=lc_fits_path, bin_seconds=bin_seconds)


def write_series(series: Series, out_path: str, template_path: Optional[str] = None) -> str:
    """
    Write a Series out as a minimal, valid .lc-style FITS file
    (TIME/RATE/ERROR columns in a 'RATE' binary table extension), so it
    stays compatible with anything downstream that reads .lc files the
    way pipeline.py's _read_rate()/read_series() do. If template_path
    is given, its RATE-extension header is copied over first (so
    keywords like TIMESYS/MJDREF/OBJECT survive), then TIME/RATE/ERROR
    are overwritten with the cropped/rebinned data.
    """
    from astropy.io import fits

    cols = [
        fits.Column(name="TIME", format="D", array=np.asarray(series.time, dtype=float)),
        fits.Column(name="RATE", format="E", array=np.asarray(series.rate, dtype=float)),
        fits.Column(name="ERROR", format="E", array=np.asarray(series.err, dtype=float)),
    ]

    header = None
    if template_path and os.path.isfile(template_path):
        try:
            with fits.open(template_path) as hdul:
                src = hdul["RATE"] if "RATE" in hdul else hdul[1]
                header = src.header.copy()
        except Exception:
            header = None

    hdu = fits.BinTableHDU.from_columns(cols, name="RATE", header=header)
    primary = fits.PrimaryHDU()
    hdul_out = fits.HDUList([primary, hdu])
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    hdul_out.writeto(out_path, overwrite=True)
    return out_path


# ---------------------------------------------------------------------------
# Crop: split a series at an x (time) range into "inside" and "outside"
# ---------------------------------------------------------------------------

def crop_series(series: Series, x1: float, x2: float) -> Tuple[Series, Series]:
    """
    Returns (inside, outside): inside = only points with x1 <= time <= x2
    (the "cropped/selected" lightcurve), outside = every other point (the
    "that section removed" lightcurve).
    """
    lo, hi = (x1, x2) if x1 <= x2 else (x2, x1)
    mask = (series.time >= lo) & (series.time <= hi)
    inside = Series(series.time[mask], series.rate[mask], series.err[mask],
                     source_path=series.source_path, bin_seconds=series.bin_seconds)
    outside = Series(series.time[~mask], series.rate[~mask], series.err[~mask],
                      source_path=series.source_path, bin_seconds=series.bin_seconds)
    return inside, outside


# ---------------------------------------------------------------------------
# Rebin: group an already-loaded series into coarser time bins ourselves
# (no external lcurve call needed -- keeps the bin-size control instant).
# ---------------------------------------------------------------------------

def rebin_series(series: Series, target_bin_seconds: float) -> Series:
    """
    Group points of `series` into contiguous target_bin_seconds-wide time
    bins. Within a bin, rate is the mean of the samples that fall in it
    and error is the propagated uncertainty of that mean
    (sqrt(sum(err_i^2)) / n). Bins with no samples are skipped (so gaps
    from earlier crops don't get filled in with fake zero points).
    """
    if len(series) == 0:
        return Series(np.array([]), np.array([]), np.array([]),
                       source_path=series.source_path, bin_seconds=target_bin_seconds)

    t0 = series.time[0]
    bin_idx = np.floor((series.time - t0) / target_bin_seconds).astype(int)

    out_t, out_r, out_e = [], [], []
    for b in np.unique(bin_idx):
        m = bin_idx == b
        n = int(m.sum())
        out_t.append(float(series.time[m].mean()))
        out_r.append(float(series.rate[m].mean()))
        out_e.append(float(np.sqrt(np.sum(series.err[m] ** 2)) / n))

    return Series(np.array(out_t), np.array(out_r), np.array(out_e),
                  source_path=series.source_path, bin_seconds=target_bin_seconds)


def with_gap_breaks(series: Series, gap_factor: float = 3.0):
    """
    Returns (time, rate, err) with a NaN row inserted wherever the gap
    to the next sample is more than gap_factor times the median
    spacing -- e.g. right where a crop removed an outburst/eclipse.
    Without this, a plain line plot draws a straight line bridging the
    gap as if that data still existed, which is misleading.
    """
    t, r, e = series.time, series.rate, series.err
    if len(t) < 2:
        return t, r, e
    dt = np.diff(t)
    med = np.median(dt)
    if med <= 0:
        return t, r, e
    gap_idx = np.where(dt > gap_factor * med)[0]
    if len(gap_idx) == 0:
        return t, r, e

    out_t, out_r, out_e = [], [], []
    prev = 0
    for gi in gap_idx:
        out_t.append(t[prev:gi + 1]); out_r.append(r[prev:gi + 1]); out_e.append(e[prev:gi + 1])
        out_t.append([np.nan]); out_r.append([np.nan]); out_e.append([np.nan])
        prev = gi + 1
    out_t.append(t[prev:]); out_r.append(r[prev:]); out_e.append(e[prev:])
    return np.concatenate(out_t), np.concatenate(out_r), np.concatenate(out_e)


def max_reasonable_bin_seconds(series: Series) -> float:
    """A sane upper limit for the Eclipse-mode bin-size control: a
    quarter of the series' current span, so at least ~4 bins remain."""
    dur = series.duration()
    if dur <= 0:
        return 10.0
    return max(10.0, dur / 4.0)


# ---------------------------------------------------------------------------
# PNG export -- black background, single white connected line (no markers),
# uncertainty shown as a translucent white error band.
# ---------------------------------------------------------------------------

def save_png(series: Series, out_png: str, title: str = "") -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 4))
    fig.patch.set_facecolor("black")
    ax.set_facecolor("black")

    t, r, e = with_gap_breaks(series)
    if len(t):
        if e is not None and np.any(np.nan_to_num(e)):
            ax.fill_between(t, r - e, r + e, color="white", alpha=0.25, linewidth=0)
        ax.plot(t, r, "-", color="white", linewidth=1.0)

    for spine in ax.spines.values():
        spine.set_color("white")
    ax.tick_params(colors="white")
    ax.xaxis.label.set_color("white")
    ax.yaxis.label.set_color("white")
    ax.title.set_color("white")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Rate (counts/s)")
    if title:
        ax.set_title(title)

    fig.tight_layout()
    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png, dpi=150, facecolor="black")
    plt.close(fig)
    return out_png
